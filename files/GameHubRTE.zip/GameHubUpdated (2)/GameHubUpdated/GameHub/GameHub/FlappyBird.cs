﻿//ECM
//ALL CODE IN FORM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
using System.IO;

namespace GameHub
{
    public partial class FlappyBird : Form
    {
       public static WindowsMediaPlayer player = new WindowsMediaPlayer();

        int pipeSpeed = 20;
        int gravity = 15;
        int score = 0;
        int highscore = 0;

        private Random random = new Random();
        private int minPipeHeight = 150;  //  150 IS MORE DIFFICULT
        private int maxPipeHeight = 321;
        private int gapSize = 110;  // 120 - 150 IS HARD DIFFICULTY

        bool gameOver = false;
        bool paused = false;


      

        public FlappyBird()
        {
            


            InitializeComponent();
            LoadHighScore();
            player.settings.volume = 30; // Adjust volume as needed

        }


        public void PlayAudio()
        {
            if (player != null)
            {
                player.controls.stop(); // Stop the player if it's already playing
                player.URL = "Theme For FlappyBird - Original Track.mp3"; // Set the new audio file path       
                player.controls.play(); // Start playback of the new audio
            }
        }

        private void FlappyBird_Load(object sender, EventArgs e)
        {
            PlayAudio();
            RespawnPipes();
            timer1.Interval = 100; // Set the timer interval to 100 milliseconds (adjust as needed)
            score_label.SendToBack();
            highscore_lbl.SendToBack();

        }

        private void FlappyBird_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
                gravity = -15;

            if (e.KeyCode == Keys.P)   //Prevents BUG that allows to pause game when it has ended, and by pressing P twice it restarted
            {
                if (!gameOver)
                    TogglePause();
            }

            if (e.KeyCode == Keys.M)  // Press "M" to change gravity and make the bird go lower
                gravity = 30;  // Change the gravity value as needed to make the bird go lower

            if (e.KeyCode == Keys.N)  
                gravity = -40;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!paused)
            {

                flappy.Top += gravity;
                pipe_up.Left -= pipeSpeed;
                pipe_down.Left -= pipeSpeed;
                score_label.Text = "Score:" + score;
             
                // if (pipe_up.Left < -150)
                if (pipe_up.Left < -pipe_up.Width)
                {
                    
                    // pipe_up.Left = 800;
                    RespawnPipes();
                    score++;
                    UpdateHighScore(); 
                   // RespawnPipes();
                } 

               /* if (pipe_down.Left < -150)
                {
                    pipe_down.Left = 800;
                    RespawnPipes();

                } */

                if (flappy.Bounds.IntersectsWith(pipe_down.Bounds) ||
                    flappy.Bounds.IntersectsWith(pipe_up.Bounds) ||
                    flappy.Bounds.IntersectsWith(ground.Bounds))
                {
                    EndGame();
                }

                if (score >= 3)
                    pipeSpeed = 30;

                if (score >= 6)
                    pipeSpeed = 35;

                if (score >= 9)
                    pipeSpeed = 40;

                if (score >= 12)
                    pipeSpeed = 45;

                if (flappy.Top < -25)
                    EndGame();
            }
        }

        private void FlappyBird_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
                gravity = 10;
            if (e.KeyCode == Keys.N)
                gravity = 10;

            if (e.KeyCode == Keys.R && gameOver)
            {
               
                RestartGame();
            }
        }
        

        private void EndGame()
        {
            timer1.Stop();
            GameOver_label.Visible = true;
            restart_label.Visible = true;
            player.controls.stop();
            gameOver = true;
            score_label.BringToFront();
            highscore_lbl.BringToFront();

        }

        private void RespawnPipes()
        {
           

            int pipeHeight = random.Next(minPipeHeight, maxPipeHeight + 1); // Generate random height for the top pipe
            int gapTop = random.Next(50, ClientSize.Height - gapSize - 100); // Ensure the top of the gap is within acceptable bounds
            int gapBottom = gapTop + gapSize; // Calculate the bottom of the gap

            // Set the position and size of the top pipe
            pipe_up.Height = gapTop;
            pipe_up.Top = 0;
            pipe_up.Left = ClientSize.Width;

            // Set the position and size of the bottom pipe
            pipe_down.Height = ClientSize.Height - gapBottom;
            pipe_down.Top = gapBottom;
            pipe_down.Left = ClientSize.Width;

          
        }

        private void RestartGame()
        {
            gameOver = false;
            paused = false;
            PauseLabel.Visible = false;
            flappy.Location = new Point(12, 180);
            pipe_down.Left = 800;
            pipe_up.Left = 800;
            score = 0;
            pipeSpeed = 20;
            score_label.Text = "Score: 0";
            timer1.Start();
            GameOver_label.Visible = false;
            restart_label.Visible= false;
            player.controls.play();
            UpdateHighScore();
            score_label.SendToBack();
            highscore_lbl.SendToBack();
        }

        

        private void back_arrow_Click(object sender, EventArgs e)
        {
            Game_Selector game_selector = new Game_Selector();
            this.Hide();
            game_selector.Show();
            Main_Menu.mplayer.controls.play();
        }

        private void UpdateHighScore() // Method to update and display high score
        {
            if (score > highscore)
            {
                highscore = score;
                highscore_lbl.Text = "High Score: " + highscore;
                SaveHighScore(); // Save the new high score
            }
        }

        private void LoadHighScore() // Method to load high score from file
        {
            if (File.Exists("highscore.txt"))
            {
                highscore = int.Parse(File.ReadAllText("highscore.txt"));
                highscore_lbl.Text = "High Score: " + highscore;
            }
        }
        private void SaveHighScore() // Method to save high score to file
        {
            File.WriteAllText("highscore.txt", highscore.ToString());
        }

        private void TogglePause()
        {
            paused = !paused; 

            if (paused)
            {
                PauseLabel.Visible = true; 
                player.controls.pause(); // Pause the audio
            }
            else
            {
                PauseLabel.Visible = false;
                player.controls.play(); // Resume the audio
            }
        }

        private void Volume_button_Click(object sender, EventArgs e)
        {
           
            if (!paused)
            {
                TogglePause();
            }

            Volume4Flappy volume = new Volume4Flappy(player.settings.volume);
            volume.ShowDialog();
        }

      
        
    }       
}

