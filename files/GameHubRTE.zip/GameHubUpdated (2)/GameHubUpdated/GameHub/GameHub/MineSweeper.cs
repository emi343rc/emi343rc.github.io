﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace GameHub
{
    public partial class MineSweeper : Form
    {

        private System.Windows.Forms.Timer timer; //Timer for tracking game
        private int seconds; //Number of seconds 
        private int nonMineSquaresClicked; //Number of non-mine squares clicked
        private DateTime timerStarted; //Timer Start
        public static WindowsMediaPlayer music = new WindowsMediaPlayer();

        //Resets the timer and updates the timer_label text to "00:00"
        private void ResetTimer()
        {
            seconds = 0;
            timerStarted = DateTime.Now;
            Timer_Label.Text = "00:00";
        }

        //Resets all buttons 
        private void ResetButtons()
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button button)
                {
                    button.Text = "";
                    button.Tag = null;
                    button.Enabled = true;

                }
                nonMineSquaresClicked = 0;

            }
        }

        //Allows player to go back to game selection

        public void PlayAudio()
        {
            if (music != null)
            {
                music.controls.stop(); // Stop the player if it's already playing
                music.URL = "Dire Docks Reprise - Helynt & GameChops.mp3"; // Set the new audio file path       
                music.controls.play(); // Start playback of the new audio
                music.settings.volume = 40;
            }
        }


        //Random Bomb Generation Event handler
        private void GenerateBombs()
        {
            Random random = new Random();
            for (int i = 0; i < 10; i++) //Assign 10 bombs for a 9x9 grid
            {
                int randomNumber = random.Next(1, 82); //Generates a random number between 1 and 81
                string buttonName = "button" + randomNumber; //Adds random number to button (e.g button42)
                Button targetButton = (Button)this.Controls.Find(buttonName, true)[0]; //finds that name out of all buttons

                if (targetButton != null)
                {
                    targetButton.Tag = true; //Set as a bomb
                }

            }



        }


        public MineSweeper()
        {
            InitializeComponent();
            PlayAudio();
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000; //initializing timer
            timer.Tick += Timer_Tick;
            timerStarted = DateTime.Now;
            seconds = 0;
            GenerateBombs(); //Calls to set bombs





            foreach (Control control in this.Controls)
            {
                if (control is Button button)
                {
                    bool flagged = false; //Flag to track if the button has been flagged

                    //When a button is clicked
                    button.Click += (sender, e) =>
                    {
                        timer.Start(); //Starts timer


                        if (!flagged)
                        {

                            if (sender != null && sender is Button clickedButton)
                            {
                                if (clickedButton.Tag != null && (bool)clickedButton.Tag) //If the buttom is clicked and has a bomb
                                {
                                    timer.Stop();
                                    MessageBox.Show("Game Over!");
                                    ResetTimer();
                                    ResetButtons();
                                    GenerateBombs();



                                }
                                else
                                {
                                    int bombCount = 0; //When button doesnt have bomb. Will display number of adjacent bombs
                                    //Lots of trial and error math to calculate adjacent bombs
                                    int clickedButtonIndex = int.Parse(clickedButton.Name.Replace("button", ""));
                                    int clickedButtonRow = (clickedButtonIndex - 1) / 9;
                                    int clickedButtonCol = (clickedButtonIndex - 1) % 9;

                                    for (int i = Math.Max(clickedButtonRow - 1, 0); i <= Math.Min(clickedButtonRow + 1, 8); i++)
                                    {
                                        for (int j = Math.Max(clickedButtonCol - 1, 0); j <= Math.Min(clickedButtonCol + 1, 8); j++)
                                        {
                                            if (i != clickedButtonRow || j != clickedButtonCol)
                                            {
                                                string buttonName = "button" + (i * 9 + j + 1);
                                                Button adjacentButton = (Button)this.Controls.Find(buttonName, true)[0];
                                                if (adjacentButton.Tag != null && (bool)adjacentButton.Tag)
                                                {
                                                    bombCount++;
                                                }
                                            }
                                        }
                                    }
                                    //Sets the button text to the bomb count

                                    clickedButton.Text = bombCount.ToString();

                                    //Change the color based on the number
                                    switch (bombCount)
                                    {
                                        case 1:
                                            clickedButton.ForeColor = Color.DarkBlue;
                                            break;
                                        case 2:
                                            clickedButton.ForeColor = Color.DarkGreen;
                                            break;
                                        case 3:
                                            clickedButton.ForeColor = Color.Navy;
                                            break;
                                        case 4:
                                            clickedButton.ForeColor = Color.Brown;
                                            break;
                                        case 5:
                                            clickedButton.ForeColor = Color.Cyan;
                                            break;
                                        case 6:
                                            clickedButton.ForeColor = Color.Purple;
                                            break;
                                        case 7:
                                            clickedButton.ForeColor = Color.DarkGray;
                                            break;
                                        case 8:
                                            clickedButton.ForeColor = Color.DarkGray;
                                            break;
                                        default:
                                            clickedButton.ForeColor = Color.Black;
                                            break;
                                    }

                                    nonMineSquaresClicked++; //Adds one to non bomb square count
                                }


                                if (nonMineSquaresClicked == 71) //81 buttons - 10 bombs. Makes it 71
                                {
                                    timer.Stop(); //Stops timer
                                    //When won Displays your time, and resets the game.
                                    int totalTimeInSeconds = seconds + (int)(DateTime.Now - timerStarted).TotalSeconds;
                                    MessageBox.Show("You Win! Your time was " + Timer_Label.Text);


                                    ResetTimer();
                                    ResetButtons();
                                    GenerateBombs();



                                }
                            }
                        }
                    };

                    //Section for flagging bombs

                    button.MouseDown += (sender, e) =>
                    {
                        if (e.Button == MouseButtons.Right && button.Text != "F") //If square has no Flag
                        {
                            button.Text = "F";
                            button.ForeColor = Color.Red;
                        }
                        else if (e.Button == MouseButtons.Right && button.Text == "F") //If square has Flag
                        {
                            button.Text = "";
                            button.ForeColor = Color.Black;
                        }
                    };


                }
            }
        }


        //Event handler for the timer tick event
        private void Timer_Tick(object sender, EventArgs e)
        {
            seconds++;
            int totalSeconds = seconds + (int)(DateTime.Now - timerStarted).TotalSeconds;
            Timer_Label.Text = TimeSpan.FromSeconds(seconds).ToString(@"mm\:ss");

        }

        private void Back_Arrow_Click_1(object sender, EventArgs e)
        {
            timer.Stop();
            ResetTimer();
            ResetButtons();
            Game_Selector game_selector = new Game_Selector();
            this.Hide();
            game_selector.Show();
            music.controls.stop();
        }
    }
}
