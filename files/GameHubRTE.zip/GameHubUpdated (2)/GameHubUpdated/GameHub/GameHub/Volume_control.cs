﻿// ECM
//ALL CODE IN FORM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    public partial class Volume_control : UserControl
    {
        public Volume_control()
        {
            InitializeComponent();
            this.Size = new Size(350, 30);
            this.BackColor = Color.Black;
            DoubleBuffered = true;
        }

        int pb_val = 40, pb_min = 0, pb_max = 100;

        public int Max {  get { return pb_max; } set { pb_max = value; Invalidate(); } }
        public int Min { get { return pb_min; } set { pb_min = value; Invalidate(); } }
        public int Value { get { return pb_val; } set { pb_val = value; Invalidate(); } }

        public int gap = 10;

        Color b_color = Color.Aqua;
        public Color Bar_color { get { return b_color; } set { b_color  = value; Invalidate(); } }




        private void Volume_control_Paint(object sender, PaintEventArgs e)
        {
            int start_point = 40;
            SolidBrush sb = new SolidBrush(Color.DimGray);
            for(int j=0; j<(Max*ClientSize.Width / Max-75) / gap; j++)
            {
                e.Graphics.FillRectangle(sb, new Rectangle(start_point,0,gap-5,ClientSize.Height));
                start_point += gap;
            }

            int buffer_point = 40;
            SolidBrush br = new SolidBrush(b_color);

            for(int i=0; i < (pb_val * ClientSize.Width / Max - pb_val) / gap; i++)
            {
                e.Graphics.FillRectangle(br,new Rectangle(buffer_point,0,gap-2,ClientSize.Height));
                buffer_point += gap;
            }

            int thum_size = 25;
            SolidBrush thumb = new SolidBrush(Color.White);
            e.Graphics.FillRectangle(thumb, new Rectangle(buffer_point, 0, thum_size, ClientSize.Height));

            if(pb_val >= Min)
            {
                Image left_image = Properties.Resources.down_img;
                e.Graphics.DrawImage(left_image, 5, 0, ClientSize.Height, ClientSize.Height);
            }
            if(pb_val<=50)
            {
                Image right_image = Properties.Resources.mid_img;
                e.Graphics.DrawImage(right_image, ClientSize.Width - 35, 0, ClientSize.Height, ClientSize.Height);
            }
            if (pb_val <= Min)
            {
                Image left_image = Properties.Resources.mute_img;
                e.Graphics.DrawImage(left_image, 5, 0, ClientSize.Height, ClientSize.Height);
            }
            if (pb_val >= 50)
            {
                Image right_image = Properties.Resources.high_img;
                e.Graphics.DrawImage(right_image, ClientSize.Width - 35, 0, ClientSize.Height, ClientSize.Height);
            }


        }

        bool mouse = false;

        //method to update volume bar wherever the user clicks on the bar
        private void Volume_control_MouseDown(object sender, MouseEventArgs e)
        {
            mouse = true;
            Bar_value(thumb_value(e.X));
        }

        //next 2 methods are so the user can slide the volume bar across
        private void Volume_control_MouseMove(object sender, MouseEventArgs e)
        {
            if(!mouse) return;
            Bar_value(thumb_value(e.X));
        }

        private void Volume_control_MouseUp(object sender, MouseEventArgs e)
        {
            mouse = false;
        }

        private void Bar_value(float value)
        {
            if(value<Min) value = Min;
            if(value>Max) value = Max;
            if (pb_val == value) return;
            pb_val = (int)value;
            this.Refresh();
        }

        private float thumb_value(int x)
        {
            return Min + (Max-Min) * x / (float)(ClientSize.Width);
        }
    }
}
