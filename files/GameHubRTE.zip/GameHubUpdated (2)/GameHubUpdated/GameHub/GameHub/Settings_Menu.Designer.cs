﻿namespace GameHub
{
    partial class Settings_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Settings_Menu));
            this.SettingsLabel = new System.Windows.Forms.Label();
            this.back_to_main = new System.Windows.Forms.Button();
            this.back_to_games = new System.Windows.Forms.Button();
            this.label_volume = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.volume_control1 = new GameHub.Volume_control();
            this.SuspendLayout();
            // 
            // SettingsLabel
            // 
            this.SettingsLabel.AutoSize = true;
            this.SettingsLabel.BackColor = System.Drawing.Color.Transparent;
            this.SettingsLabel.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsLabel.Location = new System.Drawing.Point(273, 44);
            this.SettingsLabel.Name = "SettingsLabel";
            this.SettingsLabel.Size = new System.Drawing.Size(115, 36);
            this.SettingsLabel.TabIndex = 0;
            this.SettingsLabel.Text = "Audio";
            // 
            // back_to_main
            // 
            this.back_to_main.BackColor = System.Drawing.Color.Linen;
            this.back_to_main.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_to_main.Location = new System.Drawing.Point(12, 12);
            this.back_to_main.Name = "back_to_main";
            this.back_to_main.Size = new System.Drawing.Size(123, 39);
            this.back_to_main.TabIndex = 1;
            this.back_to_main.Text = "Main Menu";
            this.back_to_main.UseVisualStyleBackColor = false;
            this.back_to_main.Click += new System.EventHandler(this.back_to_main_Click);
            // 
            // back_to_games
            // 
            this.back_to_games.BackColor = System.Drawing.Color.Linen;
            this.back_to_games.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back_to_games.Location = new System.Drawing.Point(12, 57);
            this.back_to_games.Name = "back_to_games";
            this.back_to_games.Size = new System.Drawing.Size(123, 39);
            this.back_to_games.TabIndex = 2;
            this.back_to_games.Text = "Games";
            this.back_to_games.UseVisualStyleBackColor = false;
            this.back_to_games.Click += new System.EventHandler(this.back_to_games_Click);
            // 
            // label_volume
            // 
            this.label_volume.AutoSize = true;
            this.label_volume.BackColor = System.Drawing.Color.Transparent;
            this.label_volume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_volume.Location = new System.Drawing.Point(54, 148);
            this.label_volume.Name = "label_volume";
            this.label_volume.Size = new System.Drawing.Size(127, 22);
            this.label_volume.TabIndex = 4;
            this.label_volume.Text = "Volume: 30%";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // volume_control1
            // 
            this.volume_control1.BackColor = System.Drawing.Color.Black;
            this.volume_control1.Bar_color = System.Drawing.Color.SpringGreen;
            this.volume_control1.Location = new System.Drawing.Point(58, 173);
            this.volume_control1.Max = 100;
            this.volume_control1.Min = 0;
            this.volume_control1.Name = "volume_control1";
            this.volume_control1.Size = new System.Drawing.Size(570, 30);
            this.volume_control1.TabIndex = 3;
            this.volume_control1.Value = 30;
            this.volume_control1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.volume_control1_MouseMove);
            // 
            // Settings_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(682, 403);
            this.Controls.Add(this.label_volume);
            this.Controls.Add(this.volume_control1);
            this.Controls.Add(this.back_to_games);
            this.Controls.Add(this.back_to_main);
            this.Controls.Add(this.SettingsLabel);
            this.Name = "Settings_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings_Menu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Settings_Menu_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SettingsLabel;
        private System.Windows.Forms.Button back_to_main;
        private System.Windows.Forms.Button back_to_games;
        private Volume_control volume_control1;
        private System.Windows.Forms.Label label_volume;
        private System.Windows.Forms.Timer timer1;
    }
}