﻿//ALL CODE IN FORM ECM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    public partial class Volume4Flappy : Form
    {
       // private Timer movementTimer = new Timer();
       // private PictureBox movingPictureBox = new PictureBox();
        public int InitialVolumeLevel { get; set; } // Property to store the initial volume level

        public static int VolumeLevel { get; set; }

        public Volume4Flappy(int initialVolumeLevel)
        {
            InitializeComponent();
            InitialVolumeLevel = initialVolumeLevel; // Set the initial volume level

            //movingPictureBox.Size = new Size(50, 50); // Set the size as needed
            //movingPictureBox.Image = Properties.Resources._1PZLo_; 
           // Controls.Add(movingPictureBox); // Add the PictureBox to the form
           // movingPictureBox.Visible = false; // Initially hide the PictureBox

            // Set up the movement timer
            movementTimer.Interval = 20; // Set the interval (in milliseconds) for updating the position
            movementTimer.Tick += MovementTimer_Tick; // Set up the event handler for the timer tick event

        }

        private void timerVol_Tick(object sender, EventArgs e)
        {
            label_volumef.Text = "Volume: " + volume_control1.Value.ToString() + "%";

        }

        private void volume_control1_MouseMove(object sender, MouseEventArgs e)
        {
            FlappyBird.player.settings.volume = volume_control1.Value;
            label_volumef.Text = "Volume: " + volume_control1.Value.ToString() + "%";
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Volume4Flappy_Load(object sender, EventArgs e)
        {
            // Set the volume control to the initial volume level
            volume_control1.Value = InitialVolumeLevel;
            label_volumef.Text = "Volume: " + InitialVolumeLevel.ToString() + "%";
        }

        private void MovementTimer_Tick(object sender, EventArgs e)
        {
            // Update the position of the moving PictureBox
            if (movingPictureBox.Left < ClientSize.Width)
            {
                movingPictureBox.Left += 5; // Adjust the speed of movement as needed
            }
            else
            {
                // If the PictureBox reaches the right edge of the screen, stop the timer
                movementTimer.Stop();
                movingPictureBox.Visible = false; // Optionally hide the PictureBox when it reaches the other side
            }
        }

        private void confirm_button_Click(object sender, EventArgs e)
        {
            // Start the timer to animate the PictureBox
            movingPictureBox.Visible = true; // Show the PictureBox
            movingPictureBox.Left = 0; // Set the initial position of the PictureBox
            movementTimer.Start();
        }
    }
}
