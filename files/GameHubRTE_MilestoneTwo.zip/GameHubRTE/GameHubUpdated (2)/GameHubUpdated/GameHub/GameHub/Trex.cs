﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace GameHub

//SD


{
    public partial class Trex : Form
    {
        bool jumping = false;
        int jumpSpeed = 12;
        int force = 0;
        int obstacleSpeed = 15;
        Random rand = new Random();
        int position;
        bool isGameOver = false;
        int score = 0;
        public static WindowsMediaPlayer sound = new WindowsMediaPlayer();



        public void PlayAudio()
        {
            if (sound != null)
            {
                sound.controls.stop(); // Stop the player if it's already playing
                sound.URL = "Monroe - LAKEY INSPIRED.mp3"; // Set the new audio file path       
                sound.controls.play(); // Start playback of the new audio
                sound.settings.volume = 40;
            }
        }

        public Trex()
        {
            InitializeComponent();
            PlayAudio();
            GameReset();
        }

        private void MainGameTimerEvent(object sender, EventArgs e)
        {
            dino.Top += jumpSpeed;
            txtScore.Text = "Score:" + score;

            if (jumping == true && force < 0)
            {
                jumping = false;
            }

            if (jumping == true)
            {
                jumpSpeed = -12;
                force -= 1;

            }
            else
            {
                jumpSpeed = 12;
            }

            if (dino.Top > 220 && jumping == false)//top sets trex at starting position
            {
                force = 12;
                dino.Top = 220;
                jumpSpeed = 0;
            }

            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "obstacle")// cactusus are tagged obstacle
                {
                    x.Left -= obstacleSpeed;

                    if (x.Left < -100)
                    {
                        x.Left = this.ClientSize.Width + rand.Next(200, 500) + (x.Width * 15);//spawns them in furhter away off screen
                        score++;

                    }

                    if (dino.Bounds.IntersectsWith(x.Bounds))// r to restart when u die 
                    {
                        gameTimer.Stop();
                        dino.Image = Properties.Resources.dead;// switches image of trex from running to the dead one
                        txtScore.Text += " Press R to Restart the Game !";
                        isGameOver = true;

                    }
                }

            }
            if (score > 7)
                obstacleSpeed = 20;
            if (score > 14)
                obstacleSpeed = 25;// as you go further objects come faster 
            if (score > 19)
                obstacleSpeed = 30;
        }


        private void keyisdown(object sender, KeyEventArgs e)// space down makes you jump
        {
            ;

            if (e.KeyCode == Keys.Space && jumping == false)
            {
                jumping = true;
            }

        }

        private void keyisup(object sender, KeyEventArgs e)// release space makes you fall
        {
            if (jumping == true)
            {
                jumping = false;
            }

            if (e.KeyCode == Keys.R && isGameOver == true)
            {
                GameReset();
            }
        }

        private void GameReset()// resets game
        {
            force = 12;
            jumpSpeed = 0;
            jumping = false;
            score = 0;
            obstacleSpeed = 10;
            txtScore.Text = "Score:" + score;
            dino.Image = Properties.Resources.running;
            isGameOver = false;
            //dino.Top = 358;
            dino.Location = new Point(58, 220);



            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "obstacle")
                {
                    position = this.ClientSize.Width + rand.Next(500, 800) + (x.Width * 10);

                    x.Left = position;
                }
            }

            gameTimer.Start();
        }

        private void Trex_Load(object sender, EventArgs e)
        {
            //dino.Location = new Point(58, 220);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Game_Selector game_selector = new Game_Selector();
            this.Hide();
            game_selector.Show();
            Main_Menu.mplayer.controls.play();
            sound.controls.stop();
        }
    }
}