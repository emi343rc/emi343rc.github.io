﻿namespace GameHub
{
    partial class Volume4Flappy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MusicLabel = new System.Windows.Forms.Label();
            this.volume_control1 = new GameHub.Volume_control();
            this.timerVol = new System.Windows.Forms.Timer(this.components);
            this.label_volumef = new System.Windows.Forms.Label();
            this.back_button = new System.Windows.Forms.PictureBox();
            this.setlabel = new System.Windows.Forms.Label();
            this.confirm_button = new System.Windows.Forms.Button();
            this.movingPictureBox = new System.Windows.Forms.PictureBox();
            this.movementTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.back_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // MusicLabel
            // 
            this.MusicLabel.AutoSize = true;
            this.MusicLabel.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MusicLabel.Location = new System.Drawing.Point(201, 32);
            this.MusicLabel.Name = "MusicLabel";
            this.MusicLabel.Size = new System.Drawing.Size(64, 20);
            this.MusicLabel.TabIndex = 0;
            this.MusicLabel.Text = "Music";
            // 
            // volume_control1
            // 
            this.volume_control1.BackColor = System.Drawing.Color.Black;
            this.volume_control1.Bar_color = System.Drawing.Color.DeepPink;
            this.volume_control1.Location = new System.Drawing.Point(77, 193);
            this.volume_control1.Max = 100;
            this.volume_control1.Min = 0;
            this.volume_control1.Name = "volume_control1";
            this.volume_control1.Size = new System.Drawing.Size(350, 38);
            this.volume_control1.TabIndex = 1;
            this.volume_control1.Value = 30;
            this.volume_control1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.volume_control1_MouseMove);
            // 
            // timerVol
            // 
            this.timerVol.Enabled = true;
            this.timerVol.Tick += new System.EventHandler(this.timerVol_Tick);
            // 
            // label_volumef
            // 
            this.label_volumef.AutoSize = true;
            this.label_volumef.Cursor = System.Windows.Forms.Cursors.Default;
            this.label_volumef.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_volumef.Location = new System.Drawing.Point(73, 170);
            this.label_volumef.Name = "label_volumef";
            this.label_volumef.Size = new System.Drawing.Size(128, 17);
            this.label_volumef.TabIndex = 2;
            this.label_volumef.Text = "Volume : 30%";
            // 
            // back_button
            // 
            this.back_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_button.Image = global::GameHub.Properties.Resources._1976609_200;
            this.back_button.Location = new System.Drawing.Point(12, 12);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(52, 45);
            this.back_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.back_button.TabIndex = 3;
            this.back_button.TabStop = false;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // setlabel
            // 
            this.setlabel.AutoSize = true;
            this.setlabel.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setlabel.Location = new System.Drawing.Point(166, 98);
            this.setlabel.Name = "setlabel";
            this.setlabel.Size = new System.Drawing.Size(140, 23);
            this.setlabel.TabIndex = 4;
            this.setlabel.Text = "Set Volume";
            // 
            // confirm_button
            // 
            this.confirm_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.confirm_button.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirm_button.Location = new System.Drawing.Point(183, 290);
            this.confirm_button.Name = "confirm_button";
            this.confirm_button.Size = new System.Drawing.Size(101, 36);
            this.confirm_button.TabIndex = 5;
            this.confirm_button.Text = "Confirm";
            this.confirm_button.UseVisualStyleBackColor = false;
            this.confirm_button.Click += new System.EventHandler(this.confirm_button_Click);
            // 
            // movingPictureBox
            // 
            this.movingPictureBox.Image = global::GameHub.Properties.Resources._1PZLo_;
            this.movingPictureBox.Location = new System.Drawing.Point(12, 332);
            this.movingPictureBox.Name = "movingPictureBox";
            this.movingPictureBox.Size = new System.Drawing.Size(49, 44);
            this.movingPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.movingPictureBox.TabIndex = 6;
            this.movingPictureBox.TabStop = false;
            this.movingPictureBox.Visible = false;
            // 
            // movementTimer
            // 
            this.movementTimer.Enabled = true;
            // 
            // Volume4Flappy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(482, 453);
            this.Controls.Add(this.movingPictureBox);
            this.Controls.Add(this.confirm_button);
            this.Controls.Add(this.setlabel);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.label_volumef);
            this.Controls.Add(this.volume_control1);
            this.Controls.Add(this.MusicLabel);
            this.Name = "Volume4Flappy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Volume4Flappy";
            this.Load += new System.EventHandler(this.Volume4Flappy_Load);
            ((System.ComponentModel.ISupportInitialize)(this.back_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MusicLabel;
        private Volume_control volume_control1;
        private System.Windows.Forms.Timer timerVol;
        private System.Windows.Forms.Label label_volumef;
        private System.Windows.Forms.PictureBox back_button;
        private System.Windows.Forms.Label setlabel;
        private System.Windows.Forms.Button confirm_button;
        private System.Windows.Forms.PictureBox movingPictureBox;
        private System.Windows.Forms.Timer movementTimer;
    }
}