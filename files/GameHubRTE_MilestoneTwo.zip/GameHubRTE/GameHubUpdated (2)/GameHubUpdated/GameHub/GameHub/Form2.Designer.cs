﻿namespace GameHub
{
    partial class Game_Selector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game_Selector));
            this.GamePickerLabel = new System.Windows.Forms.Label();
            this.Snake_btn = new System.Windows.Forms.Button();
            this.Mine_btn = new System.Windows.Forms.Button();
            this.Flappy_btn = new System.Windows.Forms.Button();
            this.Main_menu_button = new System.Windows.Forms.Button();
            this.Settings_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // GamePickerLabel
            // 
            this.GamePickerLabel.AutoSize = true;
            this.GamePickerLabel.Font = new System.Drawing.Font("Courier New", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GamePickerLabel.Location = new System.Drawing.Point(187, 59);
            this.GamePickerLabel.Name = "GamePickerLabel";
            this.GamePickerLabel.Size = new System.Drawing.Size(402, 42);
            this.GamePickerLabel.TabIndex = 0;
            this.GamePickerLabel.Text = "Choose Your Game";
            // 
            // Snake_btn
            // 
            this.Snake_btn.BackgroundImage = global::GameHub.Properties.Resources.dead;
            this.Snake_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Snake_btn.Location = new System.Drawing.Point(308, 159);
            this.Snake_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Snake_btn.Name = "Snake_btn";
            this.Snake_btn.Size = new System.Drawing.Size(169, 188);
            this.Snake_btn.TabIndex = 2;
            this.Snake_btn.UseVisualStyleBackColor = true;
            this.Snake_btn.Click += new System.EventHandler(this.Snake_btn_Click);
            // 
            // Mine_btn
            // 
            this.Mine_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Mine_btn.BackgroundImage")));
            this.Mine_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Mine_btn.Location = new System.Drawing.Point(568, 159);
            this.Mine_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Mine_btn.Name = "Mine_btn";
            this.Mine_btn.Size = new System.Drawing.Size(169, 188);
            this.Mine_btn.TabIndex = 3;
            this.Mine_btn.UseVisualStyleBackColor = true;
            this.Mine_btn.Click += new System.EventHandler(this.Mine_btn_Click);
            // 
            // Flappy_btn
            // 
            this.Flappy_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Flappy_btn.BackgroundImage")));
            this.Flappy_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Flappy_btn.Location = new System.Drawing.Point(66, 159);
            this.Flappy_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Flappy_btn.Name = "Flappy_btn";
            this.Flappy_btn.Size = new System.Drawing.Size(169, 188);
            this.Flappy_btn.TabIndex = 5;
            this.Flappy_btn.UseVisualStyleBackColor = true;
            this.Flappy_btn.Click += new System.EventHandler(this.Flappy_btn_Click);
            // 
            // Main_menu_button
            // 
            this.Main_menu_button.BackColor = System.Drawing.Color.Linen;
            this.Main_menu_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Main_menu_button.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Main_menu_button.Location = new System.Drawing.Point(14, 15);
            this.Main_menu_button.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Main_menu_button.Name = "Main_menu_button";
            this.Main_menu_button.Size = new System.Drawing.Size(135, 36);
            this.Main_menu_button.TabIndex = 6;
            this.Main_menu_button.Text = "Main Menu";
            this.Main_menu_button.UseVisualStyleBackColor = false;
            this.Main_menu_button.Click += new System.EventHandler(this.Main_menu_button_Click);
            // 
            // Settings_button
            // 
            this.Settings_button.BackColor = System.Drawing.Color.Linen;
            this.Settings_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Settings_button.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Settings_button.Location = new System.Drawing.Point(14, 59);
            this.Settings_button.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Settings_button.Name = "Settings_button";
            this.Settings_button.Size = new System.Drawing.Size(135, 38);
            this.Settings_button.TabIndex = 7;
            this.Settings_button.Text = "Settings";
            this.Settings_button.UseVisualStyleBackColor = false;
            this.Settings_button.Click += new System.EventHandler(this.Settings_button_Click);
            // 
            // Game_Selector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(767, 504);
            this.Controls.Add(this.Settings_button);
            this.Controls.Add(this.Main_menu_button);
            this.Controls.Add(this.Flappy_btn);
            this.Controls.Add(this.Mine_btn);
            this.Controls.Add(this.Snake_btn);
            this.Controls.Add(this.GamePickerLabel);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Game_Selector";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GameSelector";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Game_Selector_FormClosed);
            this.Load += new System.EventHandler(this.Game_Selector_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label GamePickerLabel;
        private System.Windows.Forms.Button Snake_btn;
        private System.Windows.Forms.Button Mine_btn;
        private System.Windows.Forms.Button Flappy_btn;
        private System.Windows.Forms.Button Main_menu_button;
        private System.Windows.Forms.Button Settings_button;
    }
}