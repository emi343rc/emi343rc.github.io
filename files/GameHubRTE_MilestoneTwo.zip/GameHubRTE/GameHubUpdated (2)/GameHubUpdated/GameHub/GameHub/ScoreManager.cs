﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GameHub
{
    /// Responsible for tracking current score and high score.
    /// Exposes events so UI can react
    /// Saves high score to a file.
    public class ScoreManager
    {
        private int score;
        private int highScore;
        private readonly string highScoreFilePath;

        public event Action<int> ScoreChanged;
        public event Action<int> HighScoreChanged;

        public ScoreManager(string highScoreFile = "highscore.txt")
        {
            highScoreFilePath = highScoreFile;
            LoadHighScore();
        }

        public int Score => score;
        public int HighScore => highScore;

        ///Reset current score to zero
        public void Reset()
        {
            score = 0;
            ScoreChanged?.Invoke(score);
        }

        ///Increment the current score and update high score if needed
        public void Increment(int amount = 1)
        {
            score += amount;
            ScoreChanged?.Invoke(score);

            if (score > highScore)
            {
                highScore = score;
                HighScoreChanged?.Invoke(highScore);
                SaveHighScore();
            }
        }

        private void LoadHighScore()
        {
            try
            {
                if (File.Exists(highScoreFilePath) &&
                    int.TryParse(File.ReadAllText(highScoreFilePath), out var parsed))
                {
                    highScore = parsed;
                }
            }
            catch
            {
                // Ignore I/O errors so a missing/bad file doesn't crash the game.
                highScore = 0;
            }
        }

        private void SaveHighScore()
        {
            try
            {
                File.WriteAllText(highScoreFilePath, highScore.ToString());
            }
            catch
            {
                // Ignore save errors (or log them later).
            }
        }
        ///Optional: manually persist highscore (useful on app close)
        public void Save() => SaveHighScore();
    }
}
