﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GameHub
{
    /// Responsible for tracking current score and high score.
    /// Exposes events so UI can react.
    /// Supports both local (guest) and online (MongoDB) saves.
    public class ScoreManager
    {
        private int score;
        private int highScore;
        private readonly string highScoreFilePath;

        public event Action<int> ScoreChanged;
        public event Action<int> HighScoreChanged;

        // store the current game key (for multi-difficulty scores)
        private readonly string gameKey;

        public ScoreManager(string highScoreFile = "highscore.txt", string gameKey = "FlappyBird_Easy")
        {
            highScoreFilePath = highScoreFile;
            this.gameKey = gameKey;
            LoadHighScore();
        }

        public int Score => score;
        public int HighScore => highScore;

        ///Reset current score to zero
        public void Reset()
        {
            score = 0;
            ScoreChanged?.Invoke(score);
        }

        ///Increment the current score and update high score if needed
        public void Increment(int amount = 1)
        {
            score += amount;
            ScoreChanged?.Invoke(score);

            if (score > highScore)
            {
                highScore = score;
                HighScoreChanged?.Invoke(highScore);
                SaveHighScore();
            }
        }

        private void LoadHighScore()
        {
            try
            {
                if (Session.CurrentUser != null)
                {
                    // Load from MongoDB session
                    if (Session.CurrentUser.HighScores != null &&
                        Session.CurrentUser.HighScores.TryGetValue(gameKey, out int dbHigh))
                    {
                        highScore = dbHigh;
                    }
                }
                else
                {
                    // Guest mode - load from local file
                    if (File.Exists(highScoreFilePath) &&
                        int.TryParse(File.ReadAllText(highScoreFilePath), out var parsed))
                    {
                        highScore = parsed;
                    }
                }
            }
            catch
            {
                highScore = 0;
            }
        }

        private void SaveHighScore()
        {
            try
            {
                if (Session.CurrentUser != null)
                {
                    // Save to MongoDB
                    UserService.UpdateHighScore(Session.CurrentUser.Id, gameKey, highScore);
                    Session.CurrentUser.HighScores[gameKey] = highScore;
                }
                else
                {
                    // Save to local file
                    File.WriteAllText(highScoreFilePath, highScore.ToString());
                }
            }
            catch
            {
                // ignore save errors
            }
        }
        ///Optional: manually persist highscore (useful on app close)
        public void Save() => SaveHighScore();
    }
}
