﻿namespace GameHub
{
    partial class FlappyBird
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.score_label = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.GameOver_label = new System.Windows.Forms.Label();
            this.restart_label = new System.Windows.Forms.Label();
            this.highscore_lbl = new System.Windows.Forms.Label();
            this.PauseLabel = new System.Windows.Forms.Label();
            this.Volume_button = new System.Windows.Forms.PictureBox();
            this.back_arrow = new System.Windows.Forms.PictureBox();
            this.flappy = new System.Windows.Forms.PictureBox();
            this.ground = new System.Windows.Forms.PictureBox();
            this.pipe_down = new System.Windows.Forms.PictureBox();
            this.pipe_up = new System.Windows.Forms.PictureBox();
            this.lblDifficulty = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Volume_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_arrow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flappy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up)).BeginInit();
            this.SuspendLayout();
            // 
            // score_label
            // 
            this.score_label.AutoSize = true;
            this.score_label.BackColor = System.Drawing.Color.Transparent;
            this.score_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score_label.Location = new System.Drawing.Point(9, 32);
            this.score_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.score_label.Name = "score_label";
            this.score_label.Size = new System.Drawing.Size(123, 31);
            this.score_label.TabIndex = 4;
            this.score_label.Text = "Score: 0";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 16;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // GameOver_label
            // 
            this.GameOver_label.AutoSize = true;
            this.GameOver_label.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.GameOver_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameOver_label.Location = new System.Drawing.Point(81, 106);
            this.GameOver_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.GameOver_label.Name = "GameOver_label";
            this.GameOver_label.Size = new System.Drawing.Size(309, 55);
            this.GameOver_label.TabIndex = 5;
            this.GameOver_label.Text = "Game Over !";
            this.GameOver_label.Visible = false;
            // 
            // restart_label
            // 
            this.restart_label.AutoSize = true;
            this.restart_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restart_label.Location = new System.Drawing.Point(128, 171);
            this.restart_label.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.restart_label.Name = "restart_label";
            this.restart_label.Size = new System.Drawing.Size(215, 29);
            this.restart_label.TabIndex = 6;
            this.restart_label.Text = "Press R to restart";
            this.restart_label.Visible = false;
            // 
            // highscore_lbl
            // 
            this.highscore_lbl.AutoSize = true;
            this.highscore_lbl.BackColor = System.Drawing.Color.Transparent;
            this.highscore_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highscore_lbl.Location = new System.Drawing.Point(9, 63);
            this.highscore_lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.highscore_lbl.Name = "highscore_lbl";
            this.highscore_lbl.Size = new System.Drawing.Size(175, 31);
            this.highscore_lbl.TabIndex = 8;
            this.highscore_lbl.Text = "High Score: ";
            // 
            // PauseLabel
            // 
            this.PauseLabel.AutoSize = true;
            this.PauseLabel.BackColor = System.Drawing.Color.Transparent;
            this.PauseLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PauseLabel.Location = new System.Drawing.Point(55, 106);
            this.PauseLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PauseLabel.Name = "PauseLabel";
            this.PauseLabel.Size = new System.Drawing.Size(387, 55);
            this.PauseLabel.TabIndex = 9;
            this.PauseLabel.Text = "GAME PAUSED";
            this.PauseLabel.Visible = false;
            // 
            // Volume_button
            // 
            this.Volume_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Volume_button.Image = global::GameHub.Properties.Resources._465241;
            this.Volume_button.Location = new System.Drawing.Point(54, 2);
            this.Volume_button.Margin = new System.Windows.Forms.Padding(2);
            this.Volume_button.Name = "Volume_button";
            this.Volume_button.Size = new System.Drawing.Size(31, 28);
            this.Volume_button.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Volume_button.TabIndex = 10;
            this.Volume_button.TabStop = false;
            this.Volume_button.Click += new System.EventHandler(this.Volume_button_Click);
            // 
            // back_arrow
            // 
            this.back_arrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_arrow.Image = global::GameHub.Properties.Resources._1976609_200;
            this.back_arrow.Location = new System.Drawing.Point(14, -2);
            this.back_arrow.Margin = new System.Windows.Forms.Padding(2);
            this.back_arrow.Name = "back_arrow";
            this.back_arrow.Size = new System.Drawing.Size(35, 31);
            this.back_arrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.back_arrow.TabIndex = 7;
            this.back_arrow.TabStop = false;
            this.back_arrow.Click += new System.EventHandler(this.back_arrow_Click);
            // 
            // flappy
            // 
            this.flappy.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.flappy.Image = global::GameHub.Properties.Resources.bird;
            this.flappy.Location = new System.Drawing.Point(9, 146);
            this.flappy.Margin = new System.Windows.Forms.Padding(2);
            this.flappy.Name = "flappy";
            this.flappy.Size = new System.Drawing.Size(47, 41);
            this.flappy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.flappy.TabIndex = 3;
            this.flappy.TabStop = false;
            // 
            // ground
            // 
            this.ground.Image = global::GameHub.Properties.Resources.ground;
            this.ground.Location = new System.Drawing.Point(3, 515);
            this.ground.Margin = new System.Windows.Forms.Padding(2);
            this.ground.Name = "ground";
            this.ground.Size = new System.Drawing.Size(486, 64);
            this.ground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ground.TabIndex = 2;
            this.ground.TabStop = false;
            // 
            // pipe_down
            // 
            this.pipe_down.Image = global::GameHub.Properties.Resources.pipe;
            this.pipe_down.Location = new System.Drawing.Point(426, 389);
            this.pipe_down.Margin = new System.Windows.Forms.Padding(2);
            this.pipe_down.Name = "pipe_down";
            this.pipe_down.Size = new System.Drawing.Size(63, 154);
            this.pipe_down.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_down.TabIndex = 1;
            this.pipe_down.TabStop = false;
            // 
            // pipe_up
            // 
            this.pipe_up.Image = global::GameHub.Properties.Resources.pipedown;
            this.pipe_up.Location = new System.Drawing.Point(426, -9);
            this.pipe_up.Margin = new System.Windows.Forms.Padding(2);
            this.pipe_up.Name = "pipe_up";
            this.pipe_up.Size = new System.Drawing.Size(63, 180);
            this.pipe_up.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pipe_up.TabIndex = 0;
            this.pipe_up.TabStop = false;
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.BackColor = System.Drawing.Color.Transparent;
            this.lblDifficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifficulty.ForeColor = System.Drawing.Color.LemonChiffon;
            this.lblDifficulty.Location = new System.Drawing.Point(296, 2);
            this.lblDifficulty.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(94, 25);
            this.lblDifficulty.TabIndex = 11;
            this.lblDifficulty.Text = "Difficulty";
            // 
            // FlappyBird
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(474, 571);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.PauseLabel);
            this.Controls.Add(this.Volume_button);
            this.Controls.Add(this.back_arrow);
            this.Controls.Add(this.GameOver_label);
            this.Controls.Add(this.pipe_up);
            this.Controls.Add(this.highscore_lbl);
            this.Controls.Add(this.restart_label);
            this.Controls.Add(this.flappy);
            this.Controls.Add(this.ground);
            this.Controls.Add(this.pipe_down);
            this.Controls.Add(this.score_label);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FlappyBird";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FlappyBird";
            this.Load += new System.EventHandler(this.FlappyBird_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FlappyBird_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FlappyBird_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.Volume_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.back_arrow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flappy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_down)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pipe_up)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pipe_up;
        private System.Windows.Forms.PictureBox pipe_down;
        private System.Windows.Forms.PictureBox ground;
        private System.Windows.Forms.PictureBox flappy;
        private System.Windows.Forms.Label score_label;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label GameOver_label;
        private System.Windows.Forms.Label restart_label;
        private System.Windows.Forms.PictureBox back_arrow;
        private System.Windows.Forms.Label highscore_lbl;
        private System.Windows.Forms.Label PauseLabel;
        private System.Windows.Forms.PictureBox Volume_button;
        private System.Windows.Forms.Label lblDifficulty;
    }
}