﻿namespace GameHub
{
    partial class DifficultySelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DifficultySelector));
            this.lbl_title = new System.Windows.Forms.Label();
            this.btnEasy = new System.Windows.Forms.Button();
            this.btnMedium = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblHardLockedMessage = new System.Windows.Forms.Label();
            this.HardBtn = new System.Windows.Forms.Button();
            this.back_arrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.back_arrow)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_title
            // 
            this.lbl_title.BackColor = System.Drawing.Color.Transparent;
            this.lbl_title.Image = ((System.Drawing.Image)(resources.GetObject("lbl_title.Image")));
            this.lbl_title.Location = new System.Drawing.Point(70, 10);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(671, 176);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnEasy
            // 
            this.btnEasy.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEasy.ForeColor = System.Drawing.Color.Black;
            this.btnEasy.Image = ((System.Drawing.Image)(resources.GetObject("btnEasy.Image")));
            this.btnEasy.Location = new System.Drawing.Point(364, 273);
            this.btnEasy.Name = "btnEasy";
            this.btnEasy.Size = new System.Drawing.Size(82, 34);
            this.btnEasy.TabIndex = 1;
            this.btnEasy.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEasy.UseVisualStyleBackColor = true;
            this.btnEasy.Click += new System.EventHandler(this.btnEasy_Click);
            // 
            // btnMedium
            // 
            this.btnMedium.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedium.ForeColor = System.Drawing.Color.Black;
            this.btnMedium.Image = ((System.Drawing.Image)(resources.GetObject("btnMedium.Image")));
            this.btnMedium.Location = new System.Drawing.Point(364, 313);
            this.btnMedium.Name = "btnMedium";
            this.btnMedium.Size = new System.Drawing.Size(82, 34);
            this.btnMedium.TabIndex = 2;
            this.btnMedium.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMedium.UseVisualStyleBackColor = true;
            this.btnMedium.Click += new System.EventHandler(this.btnMedium_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(330, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 40);
            this.label1.TabIndex = 4;
            // 
            // lblHardLockedMessage
            // 
            this.lblHardLockedMessage.AutoSize = true;
            this.lblHardLockedMessage.BackColor = System.Drawing.Color.Transparent;
            this.lblHardLockedMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHardLockedMessage.ForeColor = System.Drawing.Color.Red;
            this.lblHardLockedMessage.Location = new System.Drawing.Point(452, 363);
            this.lblHardLockedMessage.Name = "lblHardLockedMessage";
            this.lblHardLockedMessage.Size = new System.Drawing.Size(336, 15);
            this.lblHardLockedMessage.TabIndex = 6;
            this.lblHardLockedMessage.Text = "Hard mode is locked. Reach score 50+ in Medium to unlock.";
            this.lblHardLockedMessage.Visible = false;
            // 
            // HardBtn
            // 
            this.HardBtn.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HardBtn.ForeColor = System.Drawing.Color.Black;
            this.HardBtn.Image = global::GameHub.Properties.Resources.hardresxd;
            this.HardBtn.Location = new System.Drawing.Point(364, 353);
            this.HardBtn.Name = "HardBtn";
            this.HardBtn.Size = new System.Drawing.Size(82, 34);
            this.HardBtn.TabIndex = 7;
            this.HardBtn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.HardBtn.UseVisualStyleBackColor = true;
            this.HardBtn.Click += new System.EventHandler(this.HardBtn_Click);
            // 
            // back_arrow
            // 
            this.back_arrow.BackColor = System.Drawing.Color.Transparent;
            this.back_arrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back_arrow.Image = global::GameHub.Properties.Resources._1976609_200;
            this.back_arrow.Location = new System.Drawing.Point(20, 11);
            this.back_arrow.Margin = new System.Windows.Forms.Padding(2);
            this.back_arrow.Name = "back_arrow";
            this.back_arrow.Size = new System.Drawing.Size(35, 31);
            this.back_arrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.back_arrow.TabIndex = 8;
            this.back_arrow.TabStop = false;
            this.back_arrow.Click += new System.EventHandler(this.back_arrow_Click);
            // 
            // DifficultySelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.back_arrow);
            this.Controls.Add(this.HardBtn);
            this.Controls.Add(this.lblHardLockedMessage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMedium);
            this.Controls.Add(this.btnEasy);
            this.Controls.Add(this.lbl_title);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "DifficultySelector";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DifficultySelector";
            this.Load += new System.EventHandler(this.DifficultySelector_Load);
            ((System.ComponentModel.ISupportInitialize)(this.back_arrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Button btnEasy;
        private System.Windows.Forms.Button btnMedium;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblHardLockedMessage;
        private System.Windows.Forms.Button HardBtn;
        private System.Windows.Forms.PictureBox back_arrow;
    }
}