﻿namespace GameHub
{
    partial class MineSweeper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Timer_Label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Back_Arrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Arrow)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button1.Location = new System.Drawing.Point(188, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 0;
            this.button1.Text = " ";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button2.Location = new System.Drawing.Point(234, 20);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 50);
            this.button2.TabIndex = 1;
            this.button2.Text = " ";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button3.Location = new System.Drawing.Point(280, 20);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 50);
            this.button3.TabIndex = 2;
            this.button3.Text = " ";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button4.Location = new System.Drawing.Point(326, 20);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 50);
            this.button4.TabIndex = 3;
            this.button4.Text = " ";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button5.Location = new System.Drawing.Point(372, 20);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 4;
            this.button5.Text = " ";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button6.Location = new System.Drawing.Point(418, 20);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 5;
            this.button6.Text = " ";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button7.Location = new System.Drawing.Point(464, 20);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 50);
            this.button7.TabIndex = 6;
            this.button7.Text = " ";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button8.Location = new System.Drawing.Point(510, 20);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 50);
            this.button8.TabIndex = 7;
            this.button8.Text = " ";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button9.Location = new System.Drawing.Point(556, 20);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 50);
            this.button9.TabIndex = 8;
            this.button9.Text = " ";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button18.Location = new System.Drawing.Point(556, 66);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(50, 50);
            this.button18.TabIndex = 17;
            this.button18.Text = " ";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button17.Location = new System.Drawing.Point(510, 66);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(50, 50);
            this.button17.TabIndex = 16;
            this.button17.Text = " ";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button16.Location = new System.Drawing.Point(464, 66);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(50, 50);
            this.button16.TabIndex = 15;
            this.button16.Text = " ";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button15.Location = new System.Drawing.Point(418, 66);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(50, 50);
            this.button15.TabIndex = 14;
            this.button15.Text = " ";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button14.Location = new System.Drawing.Point(372, 66);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(50, 50);
            this.button14.TabIndex = 13;
            this.button14.Text = " ";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button13.Location = new System.Drawing.Point(326, 66);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(50, 50);
            this.button13.TabIndex = 12;
            this.button13.Text = " ";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button12.Location = new System.Drawing.Point(280, 66);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(50, 50);
            this.button12.TabIndex = 11;
            this.button12.Text = " ";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button11.Location = new System.Drawing.Point(234, 66);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(50, 50);
            this.button11.TabIndex = 10;
            this.button11.Text = " ";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button10.Location = new System.Drawing.Point(188, 66);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(50, 50);
            this.button10.TabIndex = 9;
            this.button10.Text = " ";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button36.Location = new System.Drawing.Point(556, 158);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(50, 50);
            this.button36.TabIndex = 35;
            this.button36.Text = " ";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button35.Location = new System.Drawing.Point(510, 158);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(50, 50);
            this.button35.TabIndex = 34;
            this.button35.Text = " ";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button34.Location = new System.Drawing.Point(464, 158);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(50, 50);
            this.button34.TabIndex = 33;
            this.button34.Text = " ";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button33.Location = new System.Drawing.Point(418, 158);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(50, 50);
            this.button33.TabIndex = 32;
            this.button33.Text = " ";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button32.Location = new System.Drawing.Point(372, 158);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(50, 50);
            this.button32.TabIndex = 31;
            this.button32.Text = " ";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button31.Location = new System.Drawing.Point(326, 158);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(50, 50);
            this.button31.TabIndex = 30;
            this.button31.Text = " ";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button30.Location = new System.Drawing.Point(280, 158);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(50, 50);
            this.button30.TabIndex = 29;
            this.button30.Text = " ";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button29.Location = new System.Drawing.Point(234, 158);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(50, 50);
            this.button29.TabIndex = 28;
            this.button29.Text = " ";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button28.Location = new System.Drawing.Point(188, 158);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(50, 50);
            this.button28.TabIndex = 27;
            this.button28.Text = " ";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button27.Location = new System.Drawing.Point(556, 112);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(50, 50);
            this.button27.TabIndex = 26;
            this.button27.Text = " ";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button26.Location = new System.Drawing.Point(510, 112);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(50, 50);
            this.button26.TabIndex = 25;
            this.button26.Text = " ";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button25.Location = new System.Drawing.Point(464, 112);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(50, 50);
            this.button25.TabIndex = 24;
            this.button25.Text = " ";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button24.Location = new System.Drawing.Point(418, 112);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(50, 50);
            this.button24.TabIndex = 23;
            this.button24.Text = " ";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button23.Location = new System.Drawing.Point(372, 112);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(50, 50);
            this.button23.TabIndex = 22;
            this.button23.Text = " ";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button22.Location = new System.Drawing.Point(326, 112);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(50, 50);
            this.button22.TabIndex = 21;
            this.button22.Text = " ";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button21.Location = new System.Drawing.Point(280, 112);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(50, 50);
            this.button21.TabIndex = 20;
            this.button21.Text = " ";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button20.Location = new System.Drawing.Point(234, 112);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(50, 50);
            this.button20.TabIndex = 19;
            this.button20.Text = " ";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button19.Location = new System.Drawing.Point(188, 112);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(50, 50);
            this.button19.TabIndex = 18;
            this.button19.Text = " ";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button72.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button72.Location = new System.Drawing.Point(556, 342);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(50, 50);
            this.button72.TabIndex = 71;
            this.button72.Text = " ";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button71.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button71.Location = new System.Drawing.Point(510, 342);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(50, 50);
            this.button71.TabIndex = 70;
            this.button71.Text = " ";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button70.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button70.Location = new System.Drawing.Point(464, 342);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(50, 50);
            this.button70.TabIndex = 69;
            this.button70.Text = " ";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button69.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button69.Location = new System.Drawing.Point(418, 342);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(50, 50);
            this.button69.TabIndex = 68;
            this.button69.Text = " ";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button68.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button68.Location = new System.Drawing.Point(372, 342);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(50, 50);
            this.button68.TabIndex = 67;
            this.button68.Text = " ";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button67.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button67.Location = new System.Drawing.Point(326, 342);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(50, 50);
            this.button67.TabIndex = 66;
            this.button67.Text = " ";
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button66.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button66.Location = new System.Drawing.Point(280, 342);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(50, 50);
            this.button66.TabIndex = 65;
            this.button66.Text = " ";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button65.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button65.Location = new System.Drawing.Point(234, 342);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(50, 50);
            this.button65.TabIndex = 64;
            this.button65.Text = " ";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button64.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button64.Location = new System.Drawing.Point(188, 342);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(50, 50);
            this.button64.TabIndex = 63;
            this.button64.Text = " ";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button63.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button63.Location = new System.Drawing.Point(556, 296);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(50, 50);
            this.button63.TabIndex = 62;
            this.button63.Text = " ";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button62.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button62.Location = new System.Drawing.Point(510, 296);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(50, 50);
            this.button62.TabIndex = 61;
            this.button62.Text = " ";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button61.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button61.Location = new System.Drawing.Point(464, 296);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(50, 50);
            this.button61.TabIndex = 60;
            this.button61.Text = " ";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button60.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button60.Location = new System.Drawing.Point(418, 296);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(50, 50);
            this.button60.TabIndex = 59;
            this.button60.Text = " ";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button59.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button59.Location = new System.Drawing.Point(372, 296);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(50, 50);
            this.button59.TabIndex = 58;
            this.button59.Text = " ";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button58.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button58.Location = new System.Drawing.Point(326, 296);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(50, 50);
            this.button58.TabIndex = 57;
            this.button58.Text = " ";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button57.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button57.Location = new System.Drawing.Point(280, 296);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(50, 50);
            this.button57.TabIndex = 56;
            this.button57.Text = " ";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button56.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button56.Location = new System.Drawing.Point(234, 296);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(50, 50);
            this.button56.TabIndex = 55;
            this.button56.Text = " ";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button55.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button55.Location = new System.Drawing.Point(188, 296);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(50, 50);
            this.button55.TabIndex = 54;
            this.button55.Text = " ";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button54.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button54.Location = new System.Drawing.Point(556, 250);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(50, 50);
            this.button54.TabIndex = 53;
            this.button54.Text = " ";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button53.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button53.Location = new System.Drawing.Point(510, 250);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(50, 50);
            this.button53.TabIndex = 52;
            this.button53.Text = " ";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button52.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button52.Location = new System.Drawing.Point(464, 250);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(50, 50);
            this.button52.TabIndex = 51;
            this.button52.Text = " ";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button51.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button51.Location = new System.Drawing.Point(418, 250);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(50, 50);
            this.button51.TabIndex = 50;
            this.button51.Text = " ";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button50.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button50.Location = new System.Drawing.Point(372, 250);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(50, 50);
            this.button50.TabIndex = 49;
            this.button50.Text = " ";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button49.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button49.Location = new System.Drawing.Point(326, 250);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(50, 50);
            this.button49.TabIndex = 48;
            this.button49.Text = " ";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button48.Location = new System.Drawing.Point(280, 250);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(50, 50);
            this.button48.TabIndex = 47;
            this.button48.Text = " ";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button47.Location = new System.Drawing.Point(234, 250);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(50, 50);
            this.button47.TabIndex = 46;
            this.button47.Text = " ";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button46.Location = new System.Drawing.Point(188, 250);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(50, 50);
            this.button46.TabIndex = 45;
            this.button46.Text = " ";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button45.Location = new System.Drawing.Point(556, 204);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(50, 50);
            this.button45.TabIndex = 44;
            this.button45.Text = " ";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button44.Location = new System.Drawing.Point(510, 204);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(50, 50);
            this.button44.TabIndex = 43;
            this.button44.Text = " ";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button43.Location = new System.Drawing.Point(464, 204);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(50, 50);
            this.button43.TabIndex = 42;
            this.button43.Text = " ";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button42.Location = new System.Drawing.Point(418, 204);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(50, 50);
            this.button42.TabIndex = 41;
            this.button42.Text = " ";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button41.Location = new System.Drawing.Point(372, 204);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(50, 50);
            this.button41.TabIndex = 40;
            this.button41.Text = " ";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button40.Location = new System.Drawing.Point(326, 204);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(50, 50);
            this.button40.TabIndex = 39;
            this.button40.Text = " ";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button39.Location = new System.Drawing.Point(280, 204);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(50, 50);
            this.button39.TabIndex = 38;
            this.button39.Text = " ";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button38.Location = new System.Drawing.Point(234, 204);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(50, 50);
            this.button38.TabIndex = 37;
            this.button38.Text = " ";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button37.Location = new System.Drawing.Point(188, 204);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(50, 50);
            this.button37.TabIndex = 36;
            this.button37.Text = " ";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button81.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button81.Location = new System.Drawing.Point(556, 388);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(50, 50);
            this.button81.TabIndex = 80;
            this.button81.Text = " ";
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button80.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button80.Location = new System.Drawing.Point(510, 388);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(50, 50);
            this.button80.TabIndex = 79;
            this.button80.Text = " ";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button79.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button79.Location = new System.Drawing.Point(464, 388);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(50, 50);
            this.button79.TabIndex = 78;
            this.button79.Text = " ";
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button78.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button78.Location = new System.Drawing.Point(418, 388);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(50, 50);
            this.button78.TabIndex = 77;
            this.button78.Text = " ";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button77.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button77.Location = new System.Drawing.Point(372, 388);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(50, 50);
            this.button77.TabIndex = 76;
            this.button77.Text = " ";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button76.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button76.Location = new System.Drawing.Point(326, 388);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(50, 50);
            this.button76.TabIndex = 75;
            this.button76.Text = " ";
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button75.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button75.Location = new System.Drawing.Point(280, 388);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(50, 50);
            this.button75.TabIndex = 74;
            this.button75.Text = " ";
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button74.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button74.Location = new System.Drawing.Point(234, 388);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(50, 50);
            this.button74.TabIndex = 73;
            this.button74.Text = " ";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button73.Image = global::GameHub.Properties.Resources.Blank_Box1;
            this.button73.Location = new System.Drawing.Point(188, 388);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(50, 50);
            this.button73.TabIndex = 72;
            this.button73.Text = " ";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 29);
            this.label1.TabIndex = 81;
            this.label1.Text = "Timer";
            // 
            // Timer_Label
            // 
            this.Timer_Label.AutoSize = true;
            this.Timer_Label.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold);
            this.Timer_Label.Location = new System.Drawing.Point(34, 116);
            this.Timer_Label.Name = "Timer_Label";
            this.Timer_Label.Size = new System.Drawing.Size(99, 37);
            this.Timer_Label.TabIndex = 82;
            this.Timer_Label.Text = "00:00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(624, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 29);
            this.label2.TabIndex = 83;
            this.label2.Text = "Minesweeper";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(633, 296);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 29);
            this.label3.TabIndex = 84;
            this.label3.Text = "Double click";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(670, 325);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 29);
            this.label4.TabIndex = 85;
            this.label4.Text = "to flag";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(641, 354);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 29);
            this.label5.TabIndex = 86;
            this.label5.Text = "and remove";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(696, 393);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 32);
            this.label6.TabIndex = 87;
            this.label6.Text = "F";
            // 
            // Back_Arrow
            // 
            this.Back_Arrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Back_Arrow.Image = global::GameHub.Properties.Resources._1976609_200;
            this.Back_Arrow.Location = new System.Drawing.Point(11, 11);
            this.Back_Arrow.Margin = new System.Windows.Forms.Padding(2);
            this.Back_Arrow.Name = "Back_Arrow";
            this.Back_Arrow.Size = new System.Drawing.Size(35, 31);
            this.Back_Arrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_Arrow.TabIndex = 88;
            this.Back_Arrow.TabStop = false;
            this.Back_Arrow.Click += new System.EventHandler(this.Back_Arrow_Click_1);
            // 
            // MineSweeper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Back_Arrow);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Timer_Label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Location = new System.Drawing.Point(188, 20);
            this.Name = "MineSweeper";
            this.Text = "MineSweeper";
            ((System.ComponentModel.ISupportInitialize)(this.Back_Arrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Timer_Label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox Back_Arrow;
    }
}