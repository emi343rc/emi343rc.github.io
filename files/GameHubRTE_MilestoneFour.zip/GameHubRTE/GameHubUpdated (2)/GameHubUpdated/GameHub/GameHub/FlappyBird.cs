﻿//ECM
//ALL CODE IN FORM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
using System.IO;
using System.Diagnostics;

namespace GameHub
{
    public partial class FlappyBird : Form
    {
       public static WindowsMediaPlayer player = new WindowsMediaPlayer();

        private Difficulty currentDifficulty;
        private float initialPipeSpeed; // px/sec - assigned by settings
        private float pipeSpeed;        // current pipe speed (px/sec)
        private int gapSize;
        private int minPipeHeight;
        private int maxPipeHeight;

        private DifficultySettings currentDifficultySettings;

        private Bird bird;     //Create an instance of a bird

        // Score is now handled by ScoreManager
        private ScoreManager scoreManager;
        // used to ensure we increment only once per spawned pipe
        private bool pipeScored = false;

        private Random random = new Random();

        bool gameOver = false;
        bool paused = false;

        private Stopwatch stopwatch = new Stopwatch();
        private long lastTime;





        public FlappyBird() : this(Difficulty.Easy, new DifficultySettings())
        {
        }


        public FlappyBird(Difficulty difficulty, DifficultySettings settings)
        {
            InitializeComponent();
            bird = new Bird(flappy);

            currentDifficulty = difficulty;
            currentDifficultySettings = settings;
            ApplyDifficultySettings(difficulty, settings);

            // Create ScoreManager using the difficulty-aware names
            scoreManager = new ScoreManager(
                $"{currentDifficulty}_highscore.txt",
                $"FlappyBird_{currentDifficulty}"
            );

            scoreManager.ScoreChanged += OnScoreChanged;
            scoreManager.HighScoreChanged += OnHighScoreChanged;

            // Initialize labels
            score_label.Text = $"Score: {scoreManager.Score}";
            highscore_lbl.Text = $"High Score ({currentDifficulty}): {scoreManager.HighScore}";
            lblDifficulty.ForeColor = Color.LemonChiffon;

            // Optional difficulty label (if you have one)
            if (lblDifficulty != null)
                lblDifficulty.Text = $"Difficulty: {currentDifficulty}";

            this.FormClosing += FlappyBird_FormClosing;

            player.settings.volume = 30;
        }




        private void ApplyDifficultySettings(Difficulty difficulty, DifficultySettings settings)
        {
            currentDifficulty = difficulty;
            currentDifficultySettings = settings;
            gapSize = settings.GapSize;
            minPipeHeight = settings.MinPipeHeight;
            maxPipeHeight = settings.MaxPipeHeight;
            initialPipeSpeed = settings.InitialPipeSpeed;
            pipeSpeed = initialPipeSpeed;
        }

        public void PlayAudio()
        {
            if (player != null)
            {
                player.controls.stop(); // Stop the player if it's already playing
                player.URL = "Theme For FlappyBird - Original Track.mp3"; // Set the new audio file path       
                player.controls.play(); // Start playback of the new audio
            }
        }

        private void FlappyBird_Load(object sender, EventArgs e)
        {
            PlayAudio();
            RespawnPipes();
            stopwatch.Start();
            lastTime = stopwatch.ElapsedMilliseconds;
            timer1.Interval = 16; // Set the timer interval to 100 milliseconds (adjust as needed) //Changed to 16 ms for 60FPS
            score_label.SendToBack();
            highscore_lbl.SendToBack();
            lblDifficulty.SendToBack();

        }

        private void FlappyBird_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameOver) return; // ignore input if game is over

            if (e.KeyCode == Keys.Space)
            {
                bird.Jump();
            }

            if (e.KeyCode == Keys.P)   //Prevents BUG that allows to pause game when it has ended, and by pressing P twice it restarted
            {
                if (!gameOver)
                    TogglePause();
            }

            if (e.KeyCode == Keys.M)  // Press "M" to change gravity and make the bird go lower
                bird.SuperFall();  // Change the gravity value as needed to make the bird go lower

            if (e.KeyCode == Keys.N)  
                bird.SuperJump();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!paused && !gameOver)
            {

                // Calculate how much real time passed since last frame
                long now = stopwatch.ElapsedMilliseconds;
                float deltaTime = (now - lastTime) / 1000f; // convert ms to seconds
                lastTime = now;

                // Safety clamp: prevents extremely large jumps if something went wrong
                const float maxDelta = 0.2f; // 200 ms 
                if (deltaTime > maxDelta) deltaTime = maxDelta;

                // Update bird with physics
                bird.Update(deltaTime);

                // update pipeSpeed based on thresholds for current difficulty (uses current score)
                if (currentDifficultySettings != null && currentDifficultySettings.SpeedIncrements != null && currentDifficultySettings.SpeedIncrements.Count > 0)
                {
                    // find all increments where threshold <= current score, take the highest target speed
                    var applicable = currentDifficultySettings.SpeedIncrements
                                     .Where(kv => kv.Key <= scoreManager.Score)
                                     .Select(kv => kv.Value);

                    pipeSpeed = applicable.Any() ? applicable.Max() : initialPipeSpeed;
                }
                else
                {
                    pipeSpeed = initialPipeSpeed;
                }

                // Use float displacement and round to nearest pixel to avoid accumulating truncation errors
                int dx = (int)Math.Round(pipeSpeed * deltaTime);
                pipe_up.Left -= dx;
                pipe_down.Left -= dx;

                score_label.Text = "Score:" + scoreManager.Score;

                // After pipes move, detect when they pass the bird and count once per pipe spawn:
                if (!pipeScored && pipe_up.Left + pipe_up.Width < flappy.Left)
                {
                    scoreManager.Increment();   // <-- this updates labels and highscore via events
                    pipeScored = true;
                }

                // Recycle / respawn pipes when fully off screen
                if (pipe_up.Left < -pipe_up.Width)
                {
                    RespawnPipes();
                }

                if (bird.CollidesWith(pipe_down) ||
                    bird.CollidesWith(pipe_up) ||
                    bird.CollidesWith(ground))
                {
                    EndGame();
                }
            }
        }

        private void FlappyBird_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.R && gameOver)
            {
               
                RestartGame();
            }
        }



        private void EndGame()
        {
            timer1.Stop();
            GameOver_label.Visible = true;
            restart_label.Visible = true;
            player.controls.stop();
            gameOver = true;


            int finalScore = scoreManager.Score;

            // Update database highscore if user is logged in
            if (Session.CurrentUser != null)
            {
                string difficultyKey = $"FlappyBird_{currentDifficulty}"; // example: FlappyBird_Easy
                int existingHigh = 0;

                if (Session.CurrentUser.HighScores != null &&
                    Session.CurrentUser.HighScores.TryGetValue(difficultyKey, out existingHigh))
                {
                    if (finalScore > existingHigh)
                    {
                        UserService.UpdateHighScore(Session.CurrentUser.Id, difficultyKey, finalScore);
                        Session.CurrentUser.HighScores[difficultyKey] = finalScore; // update session copy
                    }
                }
                else
                {
                    // first time saving score for this difficulty
                    UserService.UpdateHighScore(Session.CurrentUser.Id, difficultyKey, finalScore);
                    Session.CurrentUser.HighScores[difficultyKey] = finalScore;
                }

                // unlock hard if player hit 50+ on Medium and hard isn't already unlocked
                if (currentDifficulty == Difficulty.Medium && finalScore >= 50 && !GameProgress.IsHardUnlocked)
                {
                    GameProgress.UnlockHard(); // this should update local state AND persist to DB if Session.IsLoggedIn
                                               // simple notification - MessageBox:
                    
                    MessageBox.Show("Congratulations! Hard difficulty unlocked!");
                    
                }
            }

            score_label.BringToFront();
            highscore_lbl.BringToFront();
            restart_label.BringToFront();
            lblDifficulty.BringToFront();

        }

        private void RespawnPipes()
        {
           

            int pipeHeight = random.Next(minPipeHeight, maxPipeHeight + 1); // Generate random height for the top pipe
            int gapTop = random.Next(50, ClientSize.Height - gapSize - 100); // Ensure the top of the gap is within acceptable bounds
            int gapBottom = gapTop + gapSize; // Calculate the bottom of the gap

            // Set the position and size of the top pipe
            pipe_up.Height = gapTop;
            pipe_up.Top = 0;
            pipe_up.Left = ClientSize.Width;

            // Set the position and size of the bottom pipe
            pipe_down.Height = ClientSize.Height - gapBottom;
            pipe_down.Top = gapBottom;
            pipe_down.Left = ClientSize.Width;
            pipeScored = false;   // allow the next pipe to be scored once it passes the bird

        }

        private void RestartGame()
        {
            gameOver = false;
            paused = false;
            PauseLabel.Visible = false;
            /*         flappy.Location = new Point(12, 180);*/
            var startPos = new Point(12, 180);
            bird.Reset(startPos);
            pipe_down.Left = ClientSize.Width;
            pipe_up.Left = ClientSize.Width;
            pipeScored = false;
            scoreManager.Reset();
            pipeSpeed = initialPipeSpeed;
            // Reset and restart timing baseline
            stopwatch.Restart();
            lastTime = stopwatch.ElapsedMilliseconds;
            timer1.Start();
            GameOver_label.Visible = false;
            restart_label.Visible= false;
            player.controls.play();
            score_label.SendToBack();
            highscore_lbl.SendToBack();
            RespawnPipes();
        }

        

        private void back_arrow_Click(object sender, EventArgs e)
        {
            Main_Menu.mplayer.controls.play(); // if you want to resume music
            this.Close();
        }

        private void TogglePause()
        {
            paused = !paused;
            PauseLabel.Visible = paused;


            if (paused)
            {
/*                PauseLabel.Visible = true; 
*/              player.controls.pause(); // Pause the audio
                stopwatch.Stop();    // stop the stopwatch so elapsed doesn't advance while paused
            }
            else
            {
/*                PauseLabel.Visible = false;
*/              player.controls.play(); // Resume the audio
                // Resume without resetting accumulated time; set baseline to avoid a big delta
                lastTime = stopwatch.ElapsedMilliseconds;
                stopwatch.Start();
            }
        }

        private void Volume_button_Click(object sender, EventArgs e)
        {
           
            if (!paused)
            {
                TogglePause();
            }

            Volume4Flappy volume = new Volume4Flappy(player.settings.volume);
            volume.ShowDialog();
        }

        private void OnScoreChanged(int newScore)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() =>
                {
                    score_label.Text = $"Score: {newScore}";
                }));
            }
            else
            {
                score_label.Text = $"Score: {newScore}";
            }
        }

        private void OnHighScoreChanged(int newHighScore)
        {
            string labelText = $"High Score ({currentDifficulty}): {newHighScore}";

            if (InvokeRequired)
            {
                BeginInvoke(new Action(() =>
                {
                    highscore_lbl.Text = labelText;
                }));
            }
            else
            {
                highscore_lbl.Text = labelText;
            }
        }

        private void FlappyBird_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Persist highscore reliably on exit
            scoreManager?.Save();
            player.controls.stop();
        }


    }       
}

