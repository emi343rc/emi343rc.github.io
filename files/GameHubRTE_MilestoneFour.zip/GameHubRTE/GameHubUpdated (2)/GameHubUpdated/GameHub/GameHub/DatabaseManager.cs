﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;

namespace GameHub
{
    public static class DatabaseManager
    {

        private static IMongoDatabase _database;
        private static MongoClient _client;

        private const string connectionString = "mongodb+srv://emi343rc:BRC3LMxdXm2UCJcT@cluster0.qwvtxlj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        private const string databaseName = "GameHubDB";

        static DatabaseManager()
        {
            try
            {
                _client = new MongoClient(connectionString);
                _database = _client.GetDatabase(databaseName);

                if (_database == null)
                    Console.WriteLine("❌ Database reference is null — check connection string or permissions.");
                else
                    Console.WriteLine("Connected to MongoDB successfully!");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ MongoDB connection failed: {ex.Message}");
            }
        }

        public static IMongoCollection<T> GetCollection<T>(string name)
        {
            return _database.GetCollection<T>(name);
        }

    }
}
