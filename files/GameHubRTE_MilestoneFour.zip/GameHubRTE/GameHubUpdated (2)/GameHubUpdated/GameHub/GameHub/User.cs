﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace GameHub
{
    // Represents a user account stored in MongoDB
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("username")]
        public string Username { get; set; }

        [BsonElement("email")]
        public string Email { get; set; }

        // Password storage using salted PBKDF2
        [BsonElement("passwordHash")]
        public string PasswordHash { get; set; }

        [BsonElement("passwordSalt")]
        public string PasswordSalt { get; set; }

        [BsonElement("passwordIterations")]
        public int PasswordIterations { get; set; }

        [BsonElement("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Example: store highscores per game
        [BsonElement("highScores")]
        public Dictionary<string, int> HighScores { get; set; } = new Dictionary<string, int>();

        // Example: store unlocked features per user
        [BsonElement("unlocked")]
        public Dictionary<string, bool> Unlocked { get; set; } = new Dictionary<string, bool>();
    }
}
