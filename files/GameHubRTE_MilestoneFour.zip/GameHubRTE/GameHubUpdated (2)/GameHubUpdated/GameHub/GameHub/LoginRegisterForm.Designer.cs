﻿namespace GameHub
{
    partial class LoginRegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLogin = new System.Windows.Forms.Panel();
            this.lblLoginMessage = new System.Windows.Forms.Label();
            this.linkToRegister = new System.Windows.Forms.LinkLabel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtLoginPassword = new System.Windows.Forms.TextBox();
            this.txtLoginUsernameOrEmail = new System.Windows.Forms.TextBox();
            this.lblLogin = new System.Windows.Forms.Label();
            this.panelRegister = new System.Windows.Forms.Panel();
            this.lblRegisterMessage = new System.Windows.Forms.Label();
            this.linkToLogin = new System.Windows.Forms.LinkLabel();
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtRegisterConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtRegisterPassword = new System.Windows.Forms.TextBox();
            this.txtRegisterEmail = new System.Windows.Forms.TextBox();
            this.txtRegisterUsername = new System.Windows.Forms.TextBox();
            this.lblRegister = new System.Windows.Forms.Label();
            this.lblCSRegister = new System.Windows.Forms.Label();
            this.lblCSLogin = new System.Windows.Forms.Label();
            this.panelLogin.SuspendLayout();
            this.panelRegister.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogin
            // 
            this.panelLogin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLogin.Controls.Add(this.lblCSLogin);
            this.panelLogin.Controls.Add(this.lblLoginMessage);
            this.panelLogin.Controls.Add(this.linkToRegister);
            this.panelLogin.Controls.Add(this.btnLogin);
            this.panelLogin.Controls.Add(this.txtLoginPassword);
            this.panelLogin.Controls.Add(this.txtLoginUsernameOrEmail);
            this.panelLogin.Controls.Add(this.lblLogin);
            this.panelLogin.Location = new System.Drawing.Point(200, 50);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(400, 300);
            this.panelLogin.TabIndex = 0;
            // 
            // lblLoginMessage
            // 
            this.lblLoginMessage.AutoSize = true;
            this.lblLoginMessage.Location = new System.Drawing.Point(115, 67);
            this.lblLoginMessage.Name = "lblLoginMessage";
            this.lblLoginMessage.Size = new System.Drawing.Size(0, 13);
            this.lblLoginMessage.TabIndex = 5;
            // 
            // linkToRegister
            // 
            this.linkToRegister.AutoSize = true;
            this.linkToRegister.Location = new System.Drawing.Point(119, 188);
            this.linkToRegister.Name = "linkToRegister";
            this.linkToRegister.Size = new System.Drawing.Size(164, 13);
            this.linkToRegister.TabIndex = 4;
            this.linkToRegister.TabStop = true;
            this.linkToRegister.Text = "Don\'t have an account? Register";
            this.linkToRegister.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkToRegister_LinkClicked);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(158, 162);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtLoginPassword
            // 
            this.txtLoginPassword.ForeColor = System.Drawing.Color.Gray;
            this.txtLoginPassword.Location = new System.Drawing.Point(130, 121);
            this.txtLoginPassword.Name = "txtLoginPassword";
            this.txtLoginPassword.Size = new System.Drawing.Size(133, 20);
            this.txtLoginPassword.TabIndex = 2;
            this.txtLoginPassword.Text = "Password";
            this.txtLoginPassword.Enter += new System.EventHandler(this.txtLoginPassword_Enter);
            this.txtLoginPassword.Leave += new System.EventHandler(this.txtLoginPassword_Leave);
            // 
            // txtLoginUsernameOrEmail
            // 
            this.txtLoginUsernameOrEmail.ForeColor = System.Drawing.Color.Gray;
            this.txtLoginUsernameOrEmail.Location = new System.Drawing.Point(130, 95);
            this.txtLoginUsernameOrEmail.Name = "txtLoginUsernameOrEmail";
            this.txtLoginUsernameOrEmail.Size = new System.Drawing.Size(133, 20);
            this.txtLoginUsernameOrEmail.TabIndex = 1;
            this.txtLoginUsernameOrEmail.Text = "Username or Email";
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.Location = new System.Drawing.Point(160, 27);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(73, 25);
            this.lblLogin.TabIndex = 0;
            this.lblLogin.Text = "Login";
            // 
            // panelRegister
            // 
            this.panelRegister.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRegister.Controls.Add(this.lblCSRegister);
            this.panelRegister.Controls.Add(this.lblRegisterMessage);
            this.panelRegister.Controls.Add(this.linkToLogin);
            this.panelRegister.Controls.Add(this.btnRegister);
            this.panelRegister.Controls.Add(this.txtRegisterConfirmPassword);
            this.panelRegister.Controls.Add(this.txtRegisterPassword);
            this.panelRegister.Controls.Add(this.txtRegisterEmail);
            this.panelRegister.Controls.Add(this.txtRegisterUsername);
            this.panelRegister.Controls.Add(this.lblRegister);
            this.panelRegister.Location = new System.Drawing.Point(200, 50);
            this.panelRegister.Name = "panelRegister";
            this.panelRegister.Size = new System.Drawing.Size(400, 300);
            this.panelRegister.TabIndex = 1;
            this.panelRegister.Visible = false;
            // 
            // lblRegisterMessage
            // 
            this.lblRegisterMessage.AutoSize = true;
            this.lblRegisterMessage.Location = new System.Drawing.Point(115, 67);
            this.lblRegisterMessage.Name = "lblRegisterMessage";
            this.lblRegisterMessage.Size = new System.Drawing.Size(0, 13);
            this.lblRegisterMessage.TabIndex = 7;
            // 
            // linkToLogin
            // 
            this.linkToLogin.AutoSize = true;
            this.linkToLogin.Location = new System.Drawing.Point(115, 232);
            this.linkToLogin.Name = "linkToLogin";
            this.linkToLogin.Size = new System.Drawing.Size(168, 13);
            this.linkToLogin.TabIndex = 6;
            this.linkToLogin.TabStop = true;
            this.linkToLogin.Text = "Already have an account ? Log In";
            this.linkToLogin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkToLogin_LinkClicked);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(158, 206);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 5;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // txtRegisterConfirmPassword
            // 
            this.txtRegisterConfirmPassword.ForeColor = System.Drawing.Color.Gray;
            this.txtRegisterConfirmPassword.Location = new System.Drawing.Point(130, 170);
            this.txtRegisterConfirmPassword.Name = "txtRegisterConfirmPassword";
            this.txtRegisterConfirmPassword.Size = new System.Drawing.Size(132, 20);
            this.txtRegisterConfirmPassword.TabIndex = 4;
            this.txtRegisterConfirmPassword.Text = "Confirm Password";
            this.txtRegisterConfirmPassword.Enter += new System.EventHandler(this.txtRegisterConfirmPassword_Enter);
            this.txtRegisterConfirmPassword.Leave += new System.EventHandler(this.txtRegisterConfirmPassword_Leave);
            // 
            // txtRegisterPassword
            // 
            this.txtRegisterPassword.ForeColor = System.Drawing.Color.Gray;
            this.txtRegisterPassword.Location = new System.Drawing.Point(130, 143);
            this.txtRegisterPassword.Name = "txtRegisterPassword";
            this.txtRegisterPassword.Size = new System.Drawing.Size(132, 20);
            this.txtRegisterPassword.TabIndex = 3;
            this.txtRegisterPassword.Text = "Password";
            this.txtRegisterPassword.Enter += new System.EventHandler(this.txtRegisterPassword_Enter);
            this.txtRegisterPassword.Leave += new System.EventHandler(this.txtRegisterPassword_Leave);
            // 
            // txtRegisterEmail
            // 
            this.txtRegisterEmail.ForeColor = System.Drawing.Color.Gray;
            this.txtRegisterEmail.Location = new System.Drawing.Point(130, 117);
            this.txtRegisterEmail.Name = "txtRegisterEmail";
            this.txtRegisterEmail.Size = new System.Drawing.Size(132, 20);
            this.txtRegisterEmail.TabIndex = 2;
            this.txtRegisterEmail.Text = "Email";
            // 
            // txtRegisterUsername
            // 
            this.txtRegisterUsername.ForeColor = System.Drawing.Color.Gray;
            this.txtRegisterUsername.Location = new System.Drawing.Point(130, 91);
            this.txtRegisterUsername.Name = "txtRegisterUsername";
            this.txtRegisterUsername.Size = new System.Drawing.Size(132, 20);
            this.txtRegisterUsername.TabIndex = 1;
            this.txtRegisterUsername.Text = "Username";
            // 
            // lblRegister
            // 
            this.lblRegister.AutoSize = true;
            this.lblRegister.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister.Location = new System.Drawing.Point(153, 28);
            this.lblRegister.Name = "lblRegister";
            this.lblRegister.Size = new System.Drawing.Size(102, 25);
            this.lblRegister.TabIndex = 0;
            this.lblRegister.Text = "Register";
            // 
            // lblCSRegister
            // 
            this.lblCSRegister.AutoSize = true;
            this.lblCSRegister.BackColor = System.Drawing.Color.Transparent;
            this.lblCSRegister.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblCSRegister.Location = new System.Drawing.Point(268, 95);
            this.lblCSRegister.Name = "lblCSRegister";
            this.lblCSRegister.Size = new System.Drawing.Size(83, 13);
            this.lblCSRegister.TabIndex = 8;
            this.lblCSRegister.Text = "(Case Sensitive)";
            // 
            // lblCSLogin
            // 
            this.lblCSLogin.AutoSize = true;
            this.lblCSLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblCSLogin.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lblCSLogin.Location = new System.Drawing.Point(268, 98);
            this.lblCSLogin.Name = "lblCSLogin";
            this.lblCSLogin.Size = new System.Drawing.Size(83, 13);
            this.lblCSLogin.TabIndex = 9;
            this.lblCSLogin.Text = "(Case Sensitive)";
            // 
            // LoginRegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelRegister);
            this.Controls.Add(this.panelLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MinimizeBox = false;
            this.Name = "LoginRegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LoginRegisterForm";
            this.Load += new System.EventHandler(this.LoginRegisterForm_Load);
            this.panelLogin.ResumeLayout(false);
            this.panelLogin.PerformLayout();
            this.panelRegister.ResumeLayout(false);
            this.panelRegister.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Panel panelRegister;
        private System.Windows.Forms.TextBox txtLoginUsernameOrEmail;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtLoginPassword;
        private System.Windows.Forms.Label lblRegister;
        private System.Windows.Forms.TextBox txtRegisterPassword;
        private System.Windows.Forms.TextBox txtRegisterEmail;
        private System.Windows.Forms.TextBox txtRegisterUsername;
        private System.Windows.Forms.LinkLabel linkToRegister;
        private System.Windows.Forms.LinkLabel linkToLogin;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtRegisterConfirmPassword;
        private System.Windows.Forms.Label lblLoginMessage;
        private System.Windows.Forms.Label lblRegisterMessage;
        private System.Windows.Forms.Label lblCSLogin;
        private System.Windows.Forms.Label lblCSRegister;
    }
}