﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameHub
{
    public class DifficultySettings
    {
        public int GapSize { get; set; }
        public float InitialPipeSpeed { get; set; } // pixels per second
        public int MinPipeHeight { get; set; }
        public int MaxPipeHeight { get; set; }

        // Key = score threshold, Value = pipe speed when score >= key
        public Dictionary<int, float> SpeedIncrements { get; set; } = new Dictionary<int, float>();

        // Factory method
        public static DifficultySettings Create(Difficulty d)
        {
            switch (d)
            {
                case Difficulty.Easy:
                    return new DifficultySettings
                    {
                        GapSize = 150,
                        InitialPipeSpeed = 150f,
                        MinPipeHeight = 100,
                        MaxPipeHeight = 280,
                        SpeedIncrements = new Dictionary<int, float>
                        {
                            { 3, 200f },
                            { 8, 250f },
                            { 15, 300f }
                        }
                    };

                case Difficulty.Medium:
                    return new DifficultySettings
                    {
                        GapSize = 110,
                        InitialPipeSpeed = 200f,
                        MinPipeHeight = 150,
                        MaxPipeHeight = 321,
                        SpeedIncrements = new Dictionary<int, float>
                        {
                            { 3, 250f },
                            { 8, 300f },
                            { 15, 350f }
                        }
                    };

                case Difficulty.Hard:
                    return new DifficultySettings
                    {
                        GapSize = 90,
                        InitialPipeSpeed = 350f,
                        MinPipeHeight = 180,
                        MaxPipeHeight = 340,
                        SpeedIncrements = new Dictionary<int, float>
                        {
                            { 3, 450f },
                            { 8, 550f },
                            { 15, 600f }
                        }
                    };

                default:
                    // Fallback (Medium-like settings)
                    return new DifficultySettings
                    {
                        GapSize = 110,
                        InitialPipeSpeed = 200f,
                        MinPipeHeight = 150,
                        MaxPipeHeight = 321
                    };
            }
        }
    }
}
