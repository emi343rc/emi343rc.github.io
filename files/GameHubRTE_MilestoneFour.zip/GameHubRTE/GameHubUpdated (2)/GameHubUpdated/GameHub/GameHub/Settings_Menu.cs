﻿//ECM
//ALL CODE IN FORM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    public partial class Settings_Menu : Form
    {
        public Settings_Menu()
        {
            InitializeComponent();
            
        }

        
        private void back_to_main_Click(object sender, EventArgs e)
        {

            // Instead of creating a new one, find the already open Main_Menu
            var mainMenu = Application.OpenForms.OfType<Main_Menu>().FirstOrDefault();

            if (mainMenu != null)
            {
                // Show existing one
                mainMenu.Show();
                mainMenu.BringToFront();
            }
            else
            {
                // Fallback (in case it was closed)
                mainMenu = new Main_Menu();
                mainMenu.Show();
            }

            this.Hide();

        }

        private void back_to_games_Click(object sender, EventArgs e)
        {
            Game_Selector game_selector = new Game_Selector();
            this.Hide();
            game_selector.Show();
        }

        private void Settings_Menu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Main_Menu.mplayer.controls.stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label_volume.Text = "Volume: " + volume_control1.Value.ToString() + "%";
        }

        private void volume_control1_MouseMove(object sender, MouseEventArgs e)
        {
            Main_Menu.mplayer.settings.volume = volume_control1.Value;
            label_volume.Text = "Volume: " + volume_control1.Value.ToString() + "%";

        }

        private void Settings_Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
