﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    public partial class LoginRegisterForm : Form
    {
        public LoginRegisterForm()
        {
            InitializeComponent();
        }

        private void LoginRegisterForm_Load(object sender, EventArgs e)
        {
            panelLogin.Visible = true;
            panelRegister.Visible = false;
        }

        private void linkToRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) // Switch to Register Panel
        {
            panelRegister.Visible = true;
            panelLogin.Visible = false;
        }

        private void linkToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) // Switch to Login Panel
        {
            panelLogin.Visible = true;
            panelRegister.Visible = false;
        }

        private void btnLogin_Click(object sender, EventArgs e) //Generates user with given info
        {
            string userInput = txtLoginUsernameOrEmail.Text.Trim();
            string password = txtLoginPassword.Text;

            // Attempt login
            User user = UserService.Login(userInput, password);

            if (user != null)
            {
                // Store user in the current session
                Session.CurrentUser = user;

                // Read unlocks from database (if any)
                bool hardUnlocked = user.Unlocked != null &&
                                    user.Unlocked.TryGetValue("FlappyBird_Hard", out bool val) &&
                                    val;

                // Sync with app-level progress state
                GameProgress.SetHardUnlocked(hardUnlocked);

                // Display success message
                lblLoginMessage.Text = $"Welcome, {user.Username}!";
                lblLoginMessage.ForeColor = Color.Green;


                // Close login form successfully
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                // Invalid credentials
                lblLoginMessage.Text = "Invalid username/email or password.";
                lblLoginMessage.ForeColor = Color.Red;
            }
        }

        private void txtRegisterPassword_Enter(object sender, EventArgs e) //Makes the SystemPasswordChar be true when user types
        {
            if (txtRegisterPassword.Text == "Password")
            {
                txtRegisterPassword.Text = "";
                txtRegisterPassword.ForeColor = Color.Black;
                txtRegisterPassword.UseSystemPasswordChar = true; // mask the input so when user types you see black dots 
            }
        }

        private void txtRegisterPassword_Leave(object sender, EventArgs e) //Makes the placeholder text reapper when there is nothing written
        {
            if (string.IsNullOrWhiteSpace(txtRegisterPassword.Text))
            {
                txtRegisterPassword.Text = "Password";
                txtRegisterPassword.ForeColor = Color.Gray;
                txtRegisterPassword.UseSystemPasswordChar = false; // show placeholder text
            }
        }

        private void txtLoginPassword_Enter(object sender, EventArgs e) //Same as above but with Login
        {
            if (txtLoginPassword.Text == "Password")
            {
                txtLoginPassword.Text = "";
                txtLoginPassword.ForeColor = Color.Black;
                txtLoginPassword.UseSystemPasswordChar = true; //Same as above but with Login
            }
        }

        private void txtLoginPassword_Leave(object sender, EventArgs e) //Same as above but with Login
        {
            if (string.IsNullOrWhiteSpace(txtLoginPassword.Text))
            {
                txtLoginPassword.Text = "Password";
                txtLoginPassword.ForeColor = Color.Gray;
                txtLoginPassword.UseSystemPasswordChar = false; //Same as above but with Login
            }
        }

        private void txtRegisterConfirmPassword_Enter(object sender, EventArgs e) //Same as above but with Confirm Password
        {
            if (txtLoginPassword.Text == "Password")
            {
                txtRegisterConfirmPassword.Text = "";
                txtRegisterConfirmPassword.ForeColor = Color.Black;
                txtRegisterConfirmPassword.UseSystemPasswordChar = true; //Same as above but with Confirm Password
            }
        }

        private void txtRegisterConfirmPassword_Leave(object sender, EventArgs e) //Same as above but with Confirm Password
        {
            if (string.IsNullOrWhiteSpace(txtRegisterConfirmPassword.Text))
            {
                txtRegisterConfirmPassword.Text = "Confirm Password";
                txtRegisterConfirmPassword.ForeColor = Color.Gray;
                txtRegisterConfirmPassword.UseSystemPasswordChar = false; //Same as above but with Confirm Password
            }
        }

        private void btnRegister_Click(object sender, EventArgs e) //Gets the information and checks that passwords match
        {
            string username = txtRegisterUsername.Text.Trim();
            string email = txtRegisterEmail.Text.Trim();
            string password = txtRegisterPassword.Text;
            string confirmPassword = txtRegisterConfirmPassword.Text;

            if (password == "Password") password = "";
            if (confirmPassword == "Confirm Password") confirmPassword = "";

            // Check if passwords match
            if (password != confirmPassword)
            {
                lblRegisterMessage.Text = "Passwords do not match!";
                lblRegisterMessage.ForeColor = Color.Red;
                return;
            }

            if (UserService.RegisterUser(username, email, password, out string error))  //Actually registers user into database
            {
                lblRegisterMessage.Text = "Registration successful! You can now log in.";
                lblRegisterMessage.ForeColor = Color.Green;
            }
            else
            {
                lblRegisterMessage.Text = error;
                lblRegisterMessage.ForeColor = Color.Red;
            }
        }
    }
}
