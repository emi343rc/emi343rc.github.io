﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using MongoDB.Driver;

namespace GameHub
{
    public static class UserService
    {
        // collection accessor
        private static IMongoCollection<User> Users => DatabaseManager.GetCollection<User>("Users");

        // static ctor to ensure indexes exist
        static UserService()
        {
            EnsureIndexes();
        }

        private static void EnsureIndexes()
        {
            // unique index on username and email to prevent duplicates
            try
            {
                var usernameIndex = new CreateIndexModel<User>(
                    Builders<User>.IndexKeys.Ascending(u => u.Username),
                    new CreateIndexOptions { Unique = true });
                var emailIndex = new CreateIndexModel<User>(
                    Builders<User>.IndexKeys.Ascending(u => u.Email),
                    new CreateIndexOptions { Unique = true });

                Users.Indexes.CreateOne(usernameIndex);
                Users.Indexes.CreateOne(emailIndex);
            }
            catch
            {
                // ignore index creation errors (e.g. if indexes already exist)
            }
        }

        /// <summary>
        /// Attempts to register a new user. Returns true if successful; false plus error message otherwise.
        /// </summary>
        public static bool RegisterUser(string username, string email, string password, out string error)
        {
            error = null;
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                error = "Username and password are required.";
                return false;
            }

            // normalize
            username = username.Trim();
            email = email?.Trim()?.ToLowerInvariant();

            // check existing
            var existing = Users.Find(u => u.Username == username || u.Email == email).FirstOrDefault();
            if (existing != null)
            {
                if (existing.Username == username) error = "Username already exists.";
                else error = "Email already registered.";
                return false;
            }

            // Hash password
            var (hash, salt, iterations) = HashPassword(password);

            var user = new User
            {
                Username = username,
                Email = email,
                PasswordHash = hash,
                PasswordSalt = salt,
                PasswordIterations = iterations,
                CreatedAt = DateTime.UtcNow
            };

            try
            {
                Users.InsertOne(user);
                return true;
            }
            catch (Exception ex)
            {
                // handle duplicate-key race or other insertion error
                error = "Registration failed: " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// Attempts to login, returns the User if credentials match, otherwise null.
        /// </summary>
        public static User Login(string usernameOrEmail, string password)
        {
            if (string.IsNullOrWhiteSpace(usernameOrEmail) || string.IsNullOrWhiteSpace(password))
                return null;

            usernameOrEmail = usernameOrEmail.Trim();

            // find by username or email
            var user = Users.Find(u => u.Username == usernameOrEmail || u.Email == usernameOrEmail.ToLowerInvariant()).FirstOrDefault();
            if (user == null) return null;

            // verify password
            if (VerifyPassword(password, user.PasswordSalt, user.PasswordIterations, user.PasswordHash))
                return user;

            return null;
        }

        // ---------------------------
        // Password hashing helpers
        // ---------------------------
        private static (string hashBase64, string saltBase64, int iterations) HashPassword(string password)
        {
            // Generate salt
            byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            int iterations = 100_000; // PBKDF2 iteration count (tunable)
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
            {
                byte[] hash = pbkdf2.GetBytes(32); // 256-bit hash
                return (Convert.ToBase64String(hash), Convert.ToBase64String(salt), iterations);
            }
        }

        private static bool VerifyPassword(string password, string storedSaltBase64, int iterations, string storedHashBase64)
        {
            try
            {
                byte[] salt = Convert.FromBase64String(storedSaltBase64);
                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
                {
                    byte[] computed = pbkdf2.GetBytes(32);
                    byte[] stored = Convert.FromBase64String(storedHashBase64);

                    return FixedTimeEquals(computed, stored);
                }
            }
            catch
            {
                return false;
            }

        }

        // Custom fallback constant-time comparison
        private static bool FixedTimeEquals(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }

        // Update highscore only if new score is greater than stored one.
        public static void UpdateHighScoreIfGreater(string userId, string gameKey, int score)
        {
            if (string.IsNullOrEmpty(userId)) return;

            var user = Users.Find(u => u.Id == userId).FirstOrDefault();
            if (user == null) return;

            // Ensure dictionary exists in-memory
            if (user.HighScores == null) user.HighScores = new Dictionary<string, int>();

            user.HighScores.TryGetValue(gameKey, out int current);
            if (score > current)
            {
                // Update database
                var update = Builders<User>.Update.Set($"highScores.{gameKey}", score);
                Users.UpdateOne(u => u.Id == userId, update);

                // Update in-memory if it's the session user
                if (Session.CurrentUser != null && Session.CurrentUser.Id == userId)
                {
                    Session.CurrentUser.HighScores[gameKey] = score;
                }
            }
        }

        // Force-set highscore (useful for admin/debug or if you want to always overwrite)
        public static void SetHighScore(string userId, string gameKey, int score)
        {
            if (string.IsNullOrEmpty(userId)) return;
            var update = Builders<User>.Update.Set($"highScores.{gameKey}", score);
            Users.UpdateOne(u => u.Id == userId, update);

            if (Session.CurrentUser != null && Session.CurrentUser.Id == userId)
            {
                if (Session.CurrentUser.HighScores == null) Session.CurrentUser.HighScores = new Dictionary<string, int>();
                Session.CurrentUser.HighScores[gameKey] = score;
            }
        }

        // Mark an unlock flag (e.g. "FlappyBird_Hard": true)
        public static void SetUnlocked(string userId, string unlockKey, bool value)
        {
            if (string.IsNullOrEmpty(userId)) return;
            var update = Builders<User>.Update.Set($"unlocked.{unlockKey}", value);
            Users.UpdateOne(u => u.Id == userId, update);

            if (Session.CurrentUser != null && Session.CurrentUser.Id == userId)
            {
                if (Session.CurrentUser.Unlocked == null) Session.CurrentUser.Unlocked = new Dictionary<string, bool>();
                Session.CurrentUser.Unlocked[unlockKey] = value;
            }
        }

        // Get unlocked value (returns false if missing)
        public static bool GetUnlocked(string userId, string unlockKey)
        {
            if (string.IsNullOrEmpty(userId)) return false;
            var user = Users.Find(u => u.Id == userId).FirstOrDefault();
            if (user == null || user.Unlocked == null) return false;
            return user.Unlocked.TryGetValue(unlockKey, out bool val) && val;
        }

        public static void UpdateUnlock(string userId, string key, bool value)
        {
            try
            {
                var filter = Builders<User>.Filter.Eq(u => u.Id, userId);
                var update = Builders<User>.Update.Set($"unlocked.{key}", value);
                Users.UpdateOne(filter, update);
                Console.WriteLine($"[MongoDB] Updated unlock: {key} = {value} for user {userId}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating unlock: {ex.Message}");
            }
        }

        public static void UpdateHighScore(string userId, string difficultyKey, int newScore)
        {
            try
            {
                var filter = Builders<User>.Filter.Eq(u => u.Id, userId);
                var update = Builders<User>.Update.Set($"highScores.{difficultyKey}", newScore);
                Users.UpdateOne(filter, update);
                Console.WriteLine($"[MongoDB] Updated highscore: {difficultyKey} = {newScore} for user {userId}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating highscore: {ex.Message}");
            }
        }
    }
}
