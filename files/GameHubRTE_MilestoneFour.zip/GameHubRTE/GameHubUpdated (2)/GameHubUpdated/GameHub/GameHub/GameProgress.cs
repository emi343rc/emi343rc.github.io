﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameHub
{
    public static class GameProgress
    {
        // Initially locked
        public static bool IsHardUnlocked { get; private set; } = false;

        public static void UnlockHard()
        {
            if (!IsHardUnlocked)
            {
                IsHardUnlocked = true;

                // Update both local memory + MongoDB if logged in
                if (Session.IsLoggedIn && Session.CurrentUser != null)
                {
                    var user = Session.CurrentUser;

                    // Ensure dictionary exists
                    if (user.Unlocked == null)
                        user.Unlocked = new Dictionary<string, bool>();

                    user.Unlocked["FlappyBird_Hard"] = true;

                    // Update MongoDB record
                    UserService.UpdateUnlock(user.Id, "FlappyBird_Hard", true);
                }
            }
        }

        // Called after login to synchronize the state from the database
        public static void SetHardUnlocked(bool value)
        {
            IsHardUnlocked = value;
        }
    }
}
