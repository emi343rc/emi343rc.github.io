﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    /// Represents the player-controlled bird in Flappy Bird.
    /// Handles position, gravity, jumping, and collision hitbox.
    public class Bird
    {
        private PictureBox sprite ;
        private float velocity = 0f;  // bird’s vertical speed
                                      // Physics constants (tweak for balance)
        private const float Gravity = 900f;      // px/sec²
        private const float JumpStrength = -250f; // px/sec (upward)
        private const float SuperJumpStrength = -400f; // px/sec (stronger upward)
        private const float SuperFallStrength = 400f;  // px/sec (fast downward)
        public Bird(PictureBox sprite)
        {
            this.sprite = sprite;
            velocity = 0f;
        }
        /// Applies gravity and updates bird position.
        public void Update(float deltaTime)
        {
            // Apply gravity acceleration
            velocity += Gravity * deltaTime;

            // Apply velocity to position
            sprite.Top += (int)(velocity * deltaTime);
        }
        public void Jump()
        {
            velocity = JumpStrength;
        }

        /// Stronger jump (N key).
        public void SuperJump()
        {
            velocity = SuperJumpStrength;
        }

        /// Dive down faster (M key).
        public void SuperFall()
        {
            velocity = SuperFallStrength;
        }

        /// Returns the current hitbox of the bird.
        /// You can shrink this rectangle slightly to make collisions feel fairer.
        public Rectangle GetHitbox()
        {
            // shrink rectangle by a few pixels on each side for fairness
            int padding = 3;
            return new Rectangle(
                sprite.Left + padding,
                sprite.Top + padding,
                sprite.Width - (2 * padding),
                sprite.Height - (2 * padding)
            );
        }

        /// Checks collision against another PictureBox.
        public bool CollidesWith(PictureBox other)
        {
            return GetHitbox().IntersectsWith(other.Bounds);
        }

        /// Resets the bird to a starting position.
        public void Reset(Point startPosition)
        {
            sprite.Location = startPosition;
            velocity = 0f;
        }
    }
}
