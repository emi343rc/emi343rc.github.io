﻿using GameHub.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHub
{
    public partial class DifficultySelector : Form
    {
        public Difficulty SelectedDifficulty { get; private set; } = Difficulty.Medium;
        public DifficultySelector()
        {
            InitializeComponent();

            if (GameProgress.IsHardUnlocked)
            {
                // Show normal image
                HardBtn.Image = Properties.Resources.hardresxd;
            }
            else
            {
                // Show grayscale "locked" version of the image
                HardBtn.Image = ImageHelper.ToGrayScale(Properties.Resources.hardresxd);
            }

        }

        private void DifficultySelector_Load(object sender, EventArgs e)
        {
            if (!GameProgress.IsHardUnlocked)
            {
                HardBtn.Enabled = false;      // disable the button
                lblHardLockedMessage.Visible = true; // show the locked message
            }
            else
            {
                HardBtn.Enabled = true;       // enable the button
                lblHardLockedMessage.Visible = false; // hide the message
            }

        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            SelectedDifficulty = Difficulty.Easy;
            DialogResult = DialogResult.OK;
            Close();
            Main_Menu.mplayer.controls.pause();
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {
            SelectedDifficulty = Difficulty.Medium;
            DialogResult = DialogResult.OK;
            Close();
            Main_Menu.mplayer.controls.pause();
        }



        public static class ImageHelper
        {
            public static Image ToGrayScale(Image original)
            {
                Bitmap grayBitmap = new Bitmap(original.Width, original.Height);

                for (int y = 0; y < original.Height; y++)
                {
                    for (int x = 0; x < original.Width; x++)
                    {
                        Color c = ((Bitmap)original).GetPixel(x, y);

                        // Simple grayscale formula
                        int gray = (int)((c.R * 0.3) + (c.G * 0.59) + (c.B * 0.11));
                        grayBitmap.SetPixel(x, y, Color.FromArgb(c.A, gray, gray, gray));
                    }
                }

                return grayBitmap;
            }
        }

        private void HardBtn_Click(object sender, EventArgs e)
        {
            if (!GameProgress.IsHardUnlocked)
            {
                // Button is locked, ignore
                return;
            }

            var settings = DifficultySettings.Create(Difficulty.Hard);
            using (FlappyBird game = new FlappyBird(Difficulty.Hard, settings))
            {
                game.ShowDialog(); // <-- modal, blocks until closed
            }
            SelectedDifficulty = Difficulty.Hard;
            DialogResult = DialogResult.OK;
            this.Close();
            Main_Menu.mplayer.controls.pause();

        }

        private void back_arrow_Click(object sender, EventArgs e)
        {
            Game_Selector game_selector = new Game_Selector();         
            this.Close();
            game_selector.Show();
            Main_Menu.mplayer.controls.play();
        }
    }
}
