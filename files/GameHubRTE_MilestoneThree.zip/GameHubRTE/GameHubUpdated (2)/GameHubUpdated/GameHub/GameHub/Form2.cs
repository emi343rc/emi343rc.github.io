﻿//ECM
//ALL CODE IN FORM
using AxWMPLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace GameHub
{
    public partial class Game_Selector : Form
    {
        



        public Game_Selector()
        {
            InitializeComponent();
        }



        public void Flappy_btn_Click(object sender, EventArgs e)
        {
 
            using (var diff = new DifficultySelector())
            {
                if (diff.ShowDialog() == DialogResult.OK)
                {
                    var settings = DifficultySettings.Create(diff.SelectedDifficulty);
                    var flappy = new FlappyBird(diff.SelectedDifficulty, settings);
                    this.Hide();
                    flappy.Show();
                    Main_Menu.mplayer.controls.pause();
                }
            }

        }

        private void Snake_btn_Click(object sender, EventArgs e)
        {
            Trex trex = new Trex();
            this.Hide();
            trex.Show();
            Main_Menu.mplayer.controls.pause();
            
        }

        private void Mine_btn_Click(object sender, EventArgs e)
        {
            MineSweeper minesweeper = new MineSweeper();    
            this.Hide();
            minesweeper.Show();
            Main_Menu.mplayer.controls.pause();

        }

        private void Main_menu_button_Click(object sender, EventArgs e)
        {
            Main_Menu main_menu = new Main_Menu();
            this.Hide();
            main_menu.Show();
        }

        private void Settings_button_Click(object sender, EventArgs e)
        {
            Settings_Menu settings_menu = new Settings_Menu();
            this.Hide();
            settings_menu.Show();
        }
        private void Game_Selector_Load(object sender, EventArgs e)
        {

        }
        private void Game_Selector_FormClosed(object sender, FormClosedEventArgs e)
        {
            Main_Menu.mplayer.controls.stop();
        }

    }
}
