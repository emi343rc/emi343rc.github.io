﻿//ECM 
//ALL CODE IN FORM
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace GameHub
{
    public partial class Main_Menu : Form 
        
    {
        public static WindowsMediaPlayer mplayer = new WindowsMediaPlayer();

        
        public Main_Menu()
        {
            InitializeComponent();
            InitializeAudio();
               
        }

        public static WindowsMediaPlayer Player
        {
            get { return mplayer; }
        }

        private void QuitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PlayBtn_Click(object sender, EventArgs e)
        {
            Game_Selector game_selector = new Game_Selector();
            this.Hide();
            game_selector.Show();
        }
        

        private void SettingsBtn_Click(object sender, EventArgs e)
        {
            Settings_Menu settings_menu = new Settings_Menu();
            this.Hide();
            settings_menu.Show();   
        }

        private void InitializeAudio()
        {
            // Set the audio file path
            mplayer.URL = "(FREE) Lo-fi Type Beat - Rain.mp3";
            mplayer.settings.volume = 30; // Adjust volume as needed
            mplayer.controls.play();
        }

        public void StopAudio()
        {
            mplayer.controls.stop();
        }

        private void Main_Menu_FormClosed(object sender, FormClosedEventArgs e)
        {
            mplayer.controls.stop();
        }

        private void Main_Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
