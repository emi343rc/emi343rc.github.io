﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameHub
{
    public static class GameProgress
    {
        // Initially locked
        public static bool IsHardUnlocked { get; private set; } = false;

        public static void UnlockHard()
        {
            IsHardUnlocked = true;
        }
    }
}
