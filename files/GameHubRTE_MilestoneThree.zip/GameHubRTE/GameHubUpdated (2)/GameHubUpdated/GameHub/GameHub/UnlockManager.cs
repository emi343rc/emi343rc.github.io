﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GameHub
{
    public static class UnlockManager
    {
        // File stored next to exe
        private static readonly string FilePath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "unlocks.txt");

        public static bool IsHardUnlocked()
        {
            try
            {
                if (!File.Exists(FilePath)) return false;
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines)
                {
                    var parts = line.Split('=');
                    if (parts.Length == 2 && parts[0].Trim() == "HardUnlocked" &&
                        bool.TryParse(parts[1], out bool val))
                        return val;
                }
            }
            catch { /* ignore I/O errors */ }
            return false;
        }

        public static void UnlockHard()
        {
            try
            {
                File.WriteAllText(FilePath, "HardUnlocked=true");
            }
            catch { /* ignore for now */ }
        }
    }
}
